import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'super-secret-admin-panel-key-change-in-production'
)

const JWT_ALGORITHM = 'HS256'
const TOKEN_NAME = 'admin_token'
const TOKEN_EXPIRY = '7d'

export interface AuthUser {
  id: string
  yaId: string
  email: string | null
  name: string | null
  avatarUrl: string | null
  role: string
}

export async function createToken(user: AuthUser): Promise<string> {
  return new SignJWT({
    id: user.id,
    yaId: user.yaId,
    email: user.email,
    name: user.name,
    avatarUrl: user.avatarUrl,
    role: user.role,
  })
    .setProtectedHeader({ alg: JWT_ALGORITHM })
    .setIssuedAt()
    .setExpirationTime(TOKEN_EXPIRY)
    .sign(JWT_SECRET)
}

export async function verifyToken(token: string): Promise<AuthUser | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET, {
      algorithms: [JWT_ALGORITHM],
    })
    return payload as unknown as AuthUser
  } catch {
    return null
  }
}

export async function getTokenFromCookies(): Promise<string | undefined> {
  const cookieStore = await cookies()
  return cookieStore.get(TOKEN_NAME)?.value
}

export async function getAuthUser(): Promise<AuthUser | null> {
  const token = await getTokenFromCookies()
  if (!token) return null
  return verifyToken(token)
}

export function setTokenCookie(token: string): string {
  const isProduction = process.env.NODE_ENV === 'production'
  return `${TOKEN_NAME}=${token}; HttpOnly; Path=/; Max-Age=${7 * 24 * 60 * 60}; SameSite=Lax${isProduction ? '; Secure' : ''}`
}

export function clearTokenCookie(): string {
  const isProduction = process.env.NODE_ENV === 'production'
  return `${TOKEN_NAME}=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax${isProduction ? '; Secure' : ''}`
}
