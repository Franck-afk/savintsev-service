'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useTheme } from 'next-themes'
import { LoginPage } from '@/components/login-page'
import { AdminPanel } from '@/components/admin-panel'
import { LoadingScreen } from '@/components/loading-screen'

export interface AuthUser {
  id: string
  yaId: string
  email: string | null
  name: string | null
  avatarUrl: string | null
  role: string
}

type AuthState = 'loading' | 'authenticated' | 'unauthenticated'

export default function Home() {
  const [authState, setAuthState] = useState<AuthState>('loading')
  const [user, setUser] = useState<AuthUser | null>(null)
  const hasChecked = useRef(false)

  // Handle Yandex OAuth redirect with code parameter on root URL
  // If Yandex console Redirect URI is set to http://localhost:3000 (without /api/auth/yandex/callback),
  // Yandex will redirect to /?code=xxx. We detect this and redirect to the callback endpoint.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const code = params.get('code')
    const authError = params.get('error')

    if (code) {
      // Redirect to the callback endpoint with the code
      window.location.href = `/api/auth/yandex/callback?code=${encodeURIComponent(code)}`
      return
    }

    if (authError) {
      // Clean up URL and show error
      window.history.replaceState({}, '', '/')
    }
  }, [])

  useEffect(() => {
    if (hasChecked.current) return
    hasChecked.current = true

    let cancelled = false

    async function check() {
      try {
        const res = await fetch('/api/auth/me')
        if (cancelled) return
        if (res.ok) {
          const data = await res.json()
          setUser(data.user)
          setAuthState('authenticated')
        } else {
          setUser(null)
          setAuthState('unauthenticated')
        }
      } catch {
        if (!cancelled) {
          setUser(null)
          setAuthState('unauthenticated')
        }
      }
    }

    check()

    return () => {
      cancelled = true
    }
  }, [])

  const handleLogin = useCallback((loggedInUser: AuthUser) => {
    setUser(loggedInUser)
    setAuthState('authenticated')
  }, [])

  const handleLogout = useCallback(async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
    } catch {
      // ignore
    }
    setUser(null)
    setAuthState('unauthenticated')
  }, [])

  const handleUserUpdate = useCallback((updates: Partial<AuthUser>) => {
    setUser(prev => prev ? { ...prev, ...updates } : prev)
  }, [])

  if (authState === 'loading') {
    return <LoadingScreen />
  }

  if (authState === 'unauthenticated') {
    return <LoginPage onLogin={handleLogin} />
  }

  return <AdminPanel user={user!} onLogout={handleLogout} onUserUpdate={handleUserUpdate} />
}
