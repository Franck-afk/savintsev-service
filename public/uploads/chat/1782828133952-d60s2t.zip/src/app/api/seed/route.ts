import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// POST /api/seed — seed initial demo orders if none exist
export async function POST() {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const existingOrders = await db.order.count()
    if (existingOrders > 0) {
      return NextResponse.json({ message: 'Заявки уже существуют', count: existingOrders })
    }

    const now = Date.now()
    const seedOrders = [
      { clientName: 'Иванов Алексей Сергеевич', clientPhone: '+7 (900) 123-45-67', carModel: 'Toyota Camry', carPlate: 'А123МН77', description: 'Замена моторного масла и фильтров. Пробег 75 000 км.', status: 'new', priority: 'normal', estimatedCost: '8 500', assignedTo: null, createdAt: new Date(now - 1800000), userId: user.id },
      { clientName: 'Петрова Мария Ивановна', clientPhone: '+7 (901) 234-56-78', carModel: 'BMW X5', carPlate: 'В456ОР77', description: 'Диагностика двигателя. Стук при разгоне, горит Check Engine.', status: 'in_progress', priority: 'high', estimatedCost: '15 000', assignedTo: 'Мастер Иванов', createdAt: new Date(now - 7200000), userId: user.id },
      { clientName: 'Сидоров Олег Петрович', clientPhone: '+7 (902) 345-67-89', carModel: 'Kia Rio', carPlate: 'Е789СТ77', description: 'Ремонт передней подвески. Замена стоек стабилизатора.', status: 'in_progress', priority: 'normal', estimatedCost: '12 000', assignedTo: 'Мастер Петров', createdAt: new Date(now - 14400000), userId: user.id },
      { clientName: 'Козлова Елена Андреевна', clientPhone: '+7 (903) 456-78-90', carModel: 'Hyundai Tucson', carPlate: 'К012АВ77', description: 'Замена тормозных колодок и дисков (передние).', status: 'waiting', priority: 'normal', estimatedCost: '9 500', assignedTo: null, createdAt: new Date(now - 28800000), userId: user.id },
      { clientName: 'Волков Дмитрий Николаевич', clientPhone: '+7 (904) 567-89-01', carModel: 'Mercedes-Benz E-Class', carPlate: 'М345УН77', description: 'Плановое ТО-60000. Замена всех жидкостей и фильтров.', status: 'new', priority: 'low', estimatedCost: '25 000', assignedTo: null, createdAt: new Date(now - 43200000), userId: user.id },
      { clientName: 'Новикова Анна Владимировна', clientPhone: '+7 (905) 678-90-12', carModel: 'Volkswagen Polo', carPlate: 'Р678ОК77', description: 'Регулировка развал-схождения. Уводит вправо при движении.', status: 'done', priority: 'normal', estimatedCost: '4 500', assignedTo: 'Мастер Сидоров', createdAt: new Date(now - 86400000), userId: user.id },
    ]

    const created = await db.order.createMany({ data: seedOrders })

    return NextResponse.json({ message: 'Заявки созданы', count: created.count })
  } catch (error) {
    console.error('Error seeding orders:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}
