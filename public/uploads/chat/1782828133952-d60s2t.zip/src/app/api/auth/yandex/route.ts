import { NextResponse } from 'next/server'

const YANDEX_OAUTH_URL = 'https://oauth.yandex.ru/authorize'

export async function POST() {
  const clientId = process.env.YANDEX_CLIENT_ID

  if (!clientId) {
    return NextResponse.json(
      {
        error: 'YANDEX_CLIENT_ID не настроен',
        message: 'Установите переменные окружения YANDEX_CLIENT_ID и YANDEX_CLIENT_SECRET. Вы можете использовать демо-вход.',
      },
      { status: 500 }
    )
  }

  const redirectUri = process.env.YANDEX_REDIRECT_URI || ''

  const params = new URLSearchParams({
    response_type: 'code',
    client_id: clientId,
    redirect_uri: redirectUri,
  })

  const authUrl = `${YANDEX_OAUTH_URL}?${params.toString()}`

  return NextResponse.json({ url: authUrl })
}
