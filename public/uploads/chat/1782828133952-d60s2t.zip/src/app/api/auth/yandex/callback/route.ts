import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createToken, setTokenCookie } from '@/lib/auth'

const YANDEX_TOKEN_URL = 'https://oauth.yandex.ru/token'
const YANDEX_USER_INFO_URL = 'https://login.yandex.ru/info'

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get('code')
  const error = request.nextUrl.searchParams.get('error')

  if (error) {
    return NextResponse.redirect(new URL('/?auth=error', request.url))
  }

  if (!code) {
    return NextResponse.redirect(new URL('/?auth=no_code', request.url))
  }

  const clientId = process.env.YANDEX_CLIENT_ID
  const clientSecret = process.env.YANDEX_CLIENT_SECRET
  const redirectUri = process.env.YANDEX_REDIRECT_URI

  if (!clientId || !clientSecret) {
    return NextResponse.redirect(new URL('/?auth=config_error', request.url))
  }

  try {
    // Exchange code for access token
    const tokenResponse = await fetch(YANDEX_TOKEN_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri || '',
      }),
    })

    if (!tokenResponse.ok) {
      const errorData = await tokenResponse.text()
      console.error('Yandex token exchange failed:', errorData)
      return NextResponse.redirect(new URL('/?auth=token_error', request.url))
    }

    const tokenData = await tokenResponse.json()
    const accessToken = tokenData.access_token

    // Get user info from Yandex
    const userResponse = await fetch(YANDEX_USER_INFO_URL, {
      headers: {
        Authorization: `OAuth ${accessToken}`,
      },
    })

    if (!userResponse.ok) {
      console.error('Yandex user info failed:', await userResponse.text())
      return NextResponse.redirect(new URL('/?auth=user_error', request.url))
    }

    const yaUser = await userResponse.json()

    // Create or update user in database
    const user = await db.user.upsert({
      where: { yaId: String(yaUser.id) },
      update: {
        email: yaUser.default_email || yaUser.emails?.[0] || null,
        name: yaUser.real_name || yaUser.display_name || yaUser.login || null,
        avatarUrl: yaUser.default_avatar_id
          ? `https://avatars.yandex.net/get-yapic/${yaUser.default_avatar_id}/islands-200`
          : yaUser.is_avatar_empty
            ? null
            : `https://avatars.yandex.net/get-yapic/${yaUser.default_avatar_id}/islands-200`,
      },
      create: {
        yaId: String(yaUser.id),
        email: yaUser.default_email || yaUser.emails?.[0] || null,
        name: yaUser.real_name || yaUser.display_name || yaUser.login || null,
        avatarUrl: yaUser.default_avatar_id
          ? `https://avatars.yandex.net/get-yapic/${yaUser.default_avatar_id}/islands-200`
          : null,
        role: 'admin',
      },
    })

    // Create JWT token
    const token = await createToken({
      id: user.id,
      yaId: user.yaId,
      email: user.email,
      name: user.name,
      avatarUrl: user.avatarUrl,
      role: user.role,
    })

    // Redirect to home with token in cookie
    const response = NextResponse.redirect(new URL('/', request.url))
    response.headers.set('Set-Cookie', setTokenCookie(token))
    return response
  } catch (err) {
    console.error('OAuth callback error:', err)
    return NextResponse.redirect(new URL('/?auth=server_error', request.url))
  }
}
