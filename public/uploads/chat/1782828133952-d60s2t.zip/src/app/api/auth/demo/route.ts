import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createToken, setTokenCookie } from '@/lib/auth'

export async function POST() {
  try {
    // Create a demo user for testing without Yandex OAuth
    const demoYaId = 'demo_user_001'

    const user = await db.user.upsert({
      where: { yaId: demoYaId },
      update: {
        name: 'Демо Админ',
        email: 'demo@savincevac.ru',
        avatarUrl: null,
      },
      create: {
        yaId: demoYaId,
        name: 'Демо Админ',
        email: 'demo@savincevac.ru',
        avatarUrl: null,
        role: 'admin',
      },
    })

    const token = await createToken({
      id: user.id,
      yaId: user.yaId,
      email: user.email,
      name: user.name,
      avatarUrl: user.avatarUrl,
      role: user.role,
    })

    const response = NextResponse.json({
      success: true,
      user: {
        id: user.id,
        yaId: user.yaId,
        email: user.email,
        name: user.name,
        avatarUrl: user.avatarUrl,
        role: user.role,
      },
    })
    response.headers.set('Set-Cookie', setTokenCookie(token))
    return response
  } catch (err) {
    console.error('Demo login error:', err)
    return NextResponse.json({ error: 'Не удалось создать демо-пользователя' }, { status: 500 })
  }
}
