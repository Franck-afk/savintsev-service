import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

const DEFAULT_SETTINGS: Record<string, string> = {
  siteName: 'СавинцевАвтоЦентр',
  adminEmail: 'admin@savincevac.ru',
  timezone: 'Europe/Moscow (UTC+3)',
  twoFactor: 'false',
  emailNotifications: 'true',
  maintenanceMode: 'false',
  jwtTokenDuration: '7d',
}

// GET /api/settings — get all settings
export async function GET() {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const settings = await db.setting.findMany()
    const settingsMap: Record<string, string> = { ...DEFAULT_SETTINGS }
    for (const s of settings) {
      settingsMap[s.key] = s.value
    }

    return NextResponse.json({ settings: settingsMap })
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}

// PATCH /api/settings — update settings
export async function PATCH(request: Request) {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const body = await request.json()
    const { settings } = body as { settings: Record<string, string> }

    if (!settings || typeof settings !== 'object') {
      return NextResponse.json({ error: 'Неверный формат данных' }, { status: 400 })
    }

    // Upsert each setting
    for (const [key, value] of Object.entries(settings)) {
      await db.setting.upsert({
        where: { key },
        update: { value },
        create: { key, value },
      })
    }

    const updatedSettings = await db.setting.findMany()
    const settingsMap: Record<string, string> = { ...DEFAULT_SETTINGS }
    for (const s of updatedSettings) {
      settingsMap[s.key] = s.value
    }

    return NextResponse.json({ settings: settingsMap })
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}
