import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// GET /api/orders/stats — get order statistics
export async function GET() {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const orders = await db.order.findMany()

    // Counts by status
    const statusCounts: Record<string, number> = {}
    for (const order of orders) {
      statusCounts[order.status] = (statusCounts[order.status] || 0) + 1
    }

    // Revenue calculations
    const ordersWithCost = orders.filter(o => o.estimatedCost)
    const totalRevenue = ordersWithCost.reduce(
      (sum, o) => sum + parseInt(o.estimatedCost!.replace(/\s/g, ''), 10), 0
    )
    const avgCost = ordersWithCost.length > 0 ? Math.round(totalRevenue / ordersWithCost.length) : 0

    // Completion rate
    const doneCount = statusCounts['done'] || 0
    const completionRate = orders.length > 0 ? Math.round((doneCount / orders.length) * 100) : 0

    // Average completion time (from createdAt to updatedAt for done orders)
    const doneOrders = orders.filter(o => o.status === 'done')
    const avgCompletionMs = doneOrders.length > 0
      ? doneOrders.reduce((sum, o) => sum + (new Date(o.updatedAt).getTime() - new Date(o.createdAt).getTime()), 0) / doneOrders.length
      : 0
    const avgCompletionHours = Math.round(avgCompletionMs / 3600000 * 10) / 10

    // Revenue by month
    const revenueByMonth: Record<string, number> = {}
    for (const order of ordersWithCost) {
      const month = new Date(order.createdAt).toLocaleDateString('ru-RU', { year: 'numeric', month: 'short' })
      revenueByMonth[month] = (revenueByMonth[month] || 0) + parseInt(order.estimatedCost!.replace(/\s/g, ''), 10)
    }

    // Top clients
    const clientMap: Record<string, { name: string; phone: string; orders: number; totalSpent: number }> = {}
    for (const order of orders) {
      const key = order.clientPhone
      if (!clientMap[key]) {
        clientMap[key] = { name: order.clientName, phone: order.clientPhone, orders: 0, totalSpent: 0 }
      }
      clientMap[key].orders++
      if (order.estimatedCost) {
        clientMap[key].totalSpent += parseInt(order.estimatedCost.replace(/\s/g, ''), 10)
      }
    }
    const topClients = Object.values(clientMap).sort((a, b) => b.orders - a.orders)

    // Car models breakdown
    const carModelMap: Record<string, number> = {}
    for (const order of orders) {
      carModelMap[order.carModel] = (carModelMap[order.carModel] || 0) + 1
    }
    const carModels = Object.entries(carModelMap)
      .map(([model, count]) => ({ model, count }))
      .sort((a, b) => b.count - a.count)

    // Orders per day (last 30 days)
    const now = Date.now()
    const thirtyDaysAgo = new Date(now - 30 * 24 * 60 * 60 * 1000)
    const recentOrders = orders.filter(o => new Date(o.createdAt) >= thirtyDaysAgo)
    const ordersPerDay = recentOrders.length / 30

    return NextResponse.json({
      statusCounts,
      totalRevenue,
      avgCost,
      completionRate,
      avgCompletionHours,
      revenueByMonth,
      topClients,
      carModels,
      ordersPerDay: Math.round(ordersPerDay * 10) / 10,
      totalOrders: orders.length,
    })
  } catch (error) {
    console.error('Error fetching stats:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}
