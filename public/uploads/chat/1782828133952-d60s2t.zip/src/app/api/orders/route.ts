import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// GET /api/orders — list all orders
export async function GET() {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const orders = await db.order.findMany({
      orderBy: { createdAt: 'desc' },
      include: { user: { select: { id: true, name: true } } },
    })

    return NextResponse.json({ orders })
  } catch (error) {
    console.error('Error fetching orders:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}

// POST /api/orders — create a new order
export async function POST(request: Request) {
  try {
    const user = await getAuthUser()
    if (!user) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const body = await request.json()
    const { clientName, clientPhone, carModel, carPlate, description, status, priority, estimatedCost, assignedTo } = body

    if (!clientName || !clientPhone || !carModel || !description) {
      return NextResponse.json({ error: 'Заполните обязательные поля' }, { status: 400 })
    }

    const order = await db.order.create({
      data: {
        clientName,
        clientPhone,
        carModel,
        carPlate: carPlate || null,
        description,
        status: status || 'new',
        priority: priority || 'normal',
        estimatedCost: estimatedCost || null,
        assignedTo: assignedTo || null,
        userId: user.id,
      },
      include: { user: { select: { id: true, name: true } } },
    })

    return NextResponse.json({ order }, { status: 201 })
  } catch (error) {
    console.error('Error creating order:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}
