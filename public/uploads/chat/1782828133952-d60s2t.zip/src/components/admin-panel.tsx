'use client'

import { useState, useEffect, useCallback } from 'react'
import { useTheme } from 'next-themes'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  LayoutDashboard,
  Users,
  Settings,
  LogOut,
  Menu,
  ChevronRight,
  Bell,
  Search,
  Moon,
  Sun,
  Shield,
  Activity,
  UserCircle,
  Command,
  CheckCircle2,
  AlertCircle,
  Info,
  BarChart3,
  TrendingUp,
  Database,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Trash2,
  ClipboardList,
  Plus,
  Phone,
  Car,
  Edit,
  Eye,
  MoreHorizontal,
  Filter,
  Clock,
  AlertTriangle,
  Wrench,
  CircleDot,
  Loader2,
  Mail,
  Globe,
  Lock,
  CreditCard,
  Heart,
  ExternalLink,
  FileText,
  Printer,
  Download,
  PieChart as PieChartIcon,
  Target,
  DollarSign,
  Timer,
} from 'lucide-react'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart'
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Area, AreaChart, Pie, PieChart, Cell, Line, LineChart, ResponsiveContainer } from 'recharts'
import { toast } from 'sonner'
import type { AuthUser } from '@/app/page'

// ---- Constants ----
const APP_VERSION = 'v1.2.0'

// ---- Data Types ----

type SidebarItem = {
  id: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  badge?: string
  section?: string
}

type Notification = {
  id: string
  title: string
  message: string
  time: string
  type: 'info' | 'success' | 'warning' | 'error'
  read: boolean
}

type ActivityLogEntry = {
  id: string
  user: string
  action: string
  target: string
  time: string
  type: 'create' | 'update' | 'delete' | 'login'
}

type OrderStatus = 'new' | 'in_progress' | 'waiting' | 'done' | 'cancelled'
type OrderPriority = 'low' | 'normal' | 'high' | 'urgent'

type Order = {
  id: string
  clientName: string
  clientPhone: string
  carModel: string
  carPlate: string | null
  description: string
  status: OrderStatus
  priority: OrderPriority
  estimatedCost: string | null
  assignedTo: string | null
  createdAt: string
  updatedAt: string
  userId: string
  user?: { id: string; name: string | null }
}

type Client = {
  id: string
  name: string
  phone: string
  carModel: string
  lastVisit: string
  totalOrders: number
}

type OrderStats = {
  statusCounts: Record<string, number>
  totalRevenue: number
  avgCost: number
  completionRate: number
  avgCompletionHours: number
  revenueByMonth: Record<string, number>
  topClients: { name: string; phone: string; orders: number; totalSpent: number }[]
  carModels: { model: string; count: number }[]
  ordersPerDay: number
  totalOrders: number
}

// ---- Sidebar Items ----

const sidebarItems: SidebarItem[] = [
  { id: 'dashboard', label: 'Главная', icon: LayoutDashboard, section: 'Основное' },
  { id: 'orders', label: 'Заявки', icon: ClipboardList, section: 'Основное' },
  { id: 'clients', label: 'Клиенты', icon: Users, section: 'Основное' },
  { id: 'analytics', label: 'Аналитика', icon: BarChart3, section: 'Управление' },
  { id: 'settings', label: 'Настройки', icon: Settings, section: 'Управление' },
  { id: 'profile', label: 'Профиль', icon: UserCircle, section: 'Аккаунт' },
]

// ---- Chart data ----

const chartData = [
  { month: 'Янв', visits: 186, sessions: 80 },
  { month: 'Фев', visits: 305, sessions: 200 },
  { month: 'Мар', visits: 237, sessions: 120 },
  { month: 'Апр', visits: 73, sessions: 190 },
  { month: 'Май', visits: 209, sessions: 130 },
  { month: 'Июн', visits: 214, sessions: 140 },
  { month: 'Июл', visits: 320, sessions: 178 },
]

const chartConfig = {
  visits: { label: 'Посещения', color: 'var(--color-chart-1)' },
  sessions: { label: 'Сессии', color: 'var(--color-chart-2)' },
}

const areaData = [
  { day: 'Пн', cpu: 45, memory: 62 },
  { day: 'Вт', cpu: 52, memory: 58 },
  { day: 'Ср', cpu: 38, memory: 71 },
  { day: 'Чт', cpu: 65, memory: 55 },
  { day: 'Пт', cpu: 48, memory: 68 },
  { day: 'Сб', cpu: 30, memory: 45 },
  { day: 'Вс', cpu: 25, memory: 42 },
]

const areaConfig = {
  cpu: { label: 'Процессор %', color: 'var(--color-chart-3)' },
  memory: { label: 'Память %', color: 'var(--color-chart-4)' },
}

const mockNotifications: Notification[] = [
  { id: '1', title: 'Новая заявка', message: 'Поступила заявка от Иванова А.С. — замена тормозных колодок', time: '5 мин назад', type: 'info', read: false },
  { id: '2', title: 'Заявка выполнена', message: 'Заявка #12 успешно завершена — ремонт подвески', time: '1 час назад', type: 'success', read: false },
  { id: '3', title: 'Срочная заявка', message: 'Высокий приоритет — диагностика двигателя BMW X5', time: '2 часа назад', type: 'warning', read: false },
  { id: '4', title: 'Отмена заявки', message: 'Клиент отменил заявку #8 — покраска кузова', time: '3 часа назад', type: 'error', read: true },
  { id: '5', title: 'Бэкап завершён', message: 'Еженедельный бэкап выполнен успешно', time: '6 часов назад', type: 'success', read: true },
]

const mockActivity: ActivityLogEntry[] = [
  { id: '1', user: 'Демо Админ', action: 'Вход в систему', target: 'Яндекс OAuth', time: 'Только что', type: 'login' },
  { id: '2', user: 'Демо Админ', action: 'Создал заявку', target: 'Замена масла Toyota Camry', time: '15 мин назад', type: 'create' },
  { id: '3', user: 'Демо Админ', action: 'Обновил статус', target: 'Заявка #5 → В работе', time: '1 час назад', type: 'update' },
  { id: '4', user: 'Клиент', action: 'Отменил', target: 'Заявка #8 — покраска', time: '2 часа назад', type: 'delete' },
  { id: '5', user: 'Демо Админ', action: 'Завершил', target: 'Заявка #12 — ремонт подвески', time: '3 часа назад', type: 'update' },
  { id: '6', user: 'Демо Админ', action: 'Вход в систему', target: 'Демо-вход', time: '5 часов назад', type: 'login' },
  { id: '7', user: 'Демо Админ', action: 'Создал заявку', target: 'Диагностика BMW X5', time: '6 часов назад', type: 'create' },
  { id: '8', user: 'Система', action: 'Обновила', target: 'Индексы базы данных', time: '8 часов назад', type: 'update' },
]

const mockClients: Client[] = [
  { id: '1', name: 'Иванов Алексей Сергеевич', phone: '+7 (900) 123-45-67', carModel: 'Toyota Camry', lastVisit: new Date(Date.now() - 1800000).toISOString(), totalOrders: 5 },
  { id: '2', name: 'Петрова Мария Ивановна', phone: '+7 (901) 234-56-78', carModel: 'BMW X5', lastVisit: new Date(Date.now() - 7200000).toISOString(), totalOrders: 3 },
  { id: '3', name: 'Сидоров Олег Петрович', phone: '+7 (902) 345-67-89', carModel: 'Kia Rio', lastVisit: new Date(Date.now() - 14400000).toISOString(), totalOrders: 7 },
  { id: '4', name: 'Козлова Елена Андреевна', phone: '+7 (903) 456-78-90', carModel: 'Hyundai Tucson', lastVisit: new Date(Date.now() - 28800000).toISOString(), totalOrders: 2 },
  { id: '5', name: 'Волков Дмитрий Николаевич', phone: '+7 (904) 567-89-01', carModel: 'Mercedes-Benz E-Class', lastVisit: new Date(Date.now() - 43200000).toISOString(), totalOrders: 4 },
  { id: '6', name: 'Новикова Анна Владимировна', phone: '+7 (905) 678-90-12', carModel: 'Volkswagen Polo', lastVisit: new Date(Date.now() - 86400000).toISOString(), totalOrders: 6 },
  { id: '7', name: 'Морозов Игорь Петрович', phone: '+7 (906) 789-01-23', carModel: 'Audi A4', lastVisit: new Date(Date.now() - 172800000).toISOString(), totalOrders: 1 },
]

// ---- Helper functions ----

const statusConfig: Record<OrderStatus, { label: string; color: string; bg: string; icon: React.ComponentType<{ className?: string }>; description: string }> = {
  new: { label: 'Новая', color: 'text-sky-700 dark:text-sky-300', bg: 'bg-sky-100 dark:bg-sky-900/30', icon: CircleDot, description: 'Заявка создана, ожидает принятия в работу' },
  in_progress: { label: 'В работе', color: 'text-amber-700 dark:text-amber-300', bg: 'bg-amber-100 dark:bg-amber-900/30', icon: Wrench, description: 'Мастер ведёт работу по заявке' },
  waiting: { label: 'Ожидание', color: 'text-violet-700 dark:text-violet-300', bg: 'bg-violet-100 dark:bg-violet-900/30', icon: Clock, description: 'Ожидание запчастей или клиента' },
  done: { label: 'Выполнена', color: 'text-emerald-700 dark:text-emerald-300', bg: 'bg-emerald-100 dark:bg-emerald-900/30', icon: CheckCircle2, description: 'Работы завершены, заявка закрыта' },
  cancelled: { label: 'Отменена', color: 'text-red-700 dark:text-red-300', bg: 'bg-red-100 dark:bg-red-900/30', icon: AlertCircle, description: 'Заявка отменена клиентом или администрацией' },
}

const statusBorderColor: Record<OrderStatus, string> = {
  new: 'border-l-sky-500',
  in_progress: 'border-l-amber-500',
  waiting: 'border-l-violet-500',
  done: 'border-l-emerald-500',
  cancelled: 'border-l-red-500',
}

const priorityConfig: Record<OrderPriority, { label: string; color: string; bg: string }> = {
  low: { label: 'Низкий', color: 'text-slate-600 dark:text-slate-400', bg: 'bg-slate-100 dark:bg-slate-800' },
  normal: { label: 'Обычный', color: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-50 dark:bg-sky-950/40' },
  high: { label: 'Высокий', color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/40' },
  urgent: { label: 'Срочный', color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-950/40' },
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'Только что'
  if (mins < 60) return `${mins} мин назад`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours} ч назад`
  const days = Math.floor(hours / 24)
  return `${days} дн назад`
}

function getInitials(name: string): string {
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
}

// ---- Skeleton Loaders ----

function DashboardSkeleton() {
  return (
    <div className="space-y-8 animate-in fade-in-0 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-7 w-48" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-36 rounded-2xl" />
        ))}
      </div>
      <Skeleton className="h-40 rounded-2xl" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Skeleton className="h-[350px] rounded-2xl" />
        <Skeleton className="h-[350px] rounded-2xl" />
      </div>
    </div>
  )
}

function OrdersSkeleton() {
  return (
    <div className="space-y-6 animate-in fade-in-0 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-10 w-36" />
      </div>
      <div className="flex gap-3">
        <Skeleton className="h-10 flex-1 rounded-xl" />
        <Skeleton className="h-10 w-64 rounded-xl" />
      </div>
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={i} className="h-24 rounded-2xl" />
      ))}
    </div>
  )
}

// ---- Sidebar Content ----

function SidebarContent({
  user,
  activeItem,
  onItemSelect,
  orders,
}: {
  user: AuthUser
  activeItem: string
  onItemSelect: (id: string) => void
  orders: Order[]
}) {
  const userInitials = user.name
    ? user.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)
    : 'A'

  const dynamicSidebarItems = sidebarItems.map(item => {
    if (item.id === 'orders') {
      return { ...item, badge: String(orders.length) }
    }
    return item
  })

  const sections = dynamicSidebarItems.reduce((acc, item) => {
    const section = item.section || 'Другое'
    if (!acc[section]) acc[section] = []
    acc[section].push(item)
    return acc
  }, {} as Record<string, SidebarItem[]>)

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 px-5 py-5 border-b">
        <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 dark:from-slate-100 dark:to-slate-200 text-white dark:text-slate-900 shadow-md">
          <Shield className="w-5 h-5" />
        </div>
        <div className="flex flex-col">
          <span className="font-bold text-sm tracking-tight">СавинцевАвтоЦентр</span>
          <span className="text-[11px] text-muted-foreground">Панель управления</span>
        </div>
      </div>

      <ScrollArea className="flex-1 py-3">
        <div className="px-3 space-y-5">
          {Object.entries(sections).map(([section, items]) => (
            <div key={section}>
              <p className="px-3 mb-2 text-[11px] font-semibold text-muted-foreground/70 uppercase tracking-widest">
                {section}
              </p>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon
                  const isActive = activeItem === item.id
                  return (
                    <button
                      key={item.id}
                      onClick={() => onItemSelect(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group cursor-pointer ${
                        isActive
                          ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20'
                          : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 transition-transform duration-200 ${isActive ? '' : 'group-hover:scale-110'}`} />
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.badge && (
                        <Badge
                          variant={isActive ? 'secondary' : 'outline'}
                          className="text-[10px] px-1.5 py-0 h-5 font-semibold"
                        >
                          {item.badge}
                        </Badge>
                      )}
                      {isActive && (
                        <ChevronRight className="w-3 h-3 opacity-60" />
                      )}
                    </button>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="border-t p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9 ring-2 ring-primary/20">
            <AvatarImage src={user.avatarUrl || undefined} alt={user.name || 'Пользователь'} />
            <AvatarFallback className="text-xs bg-gradient-to-br from-slate-700 to-slate-900 dark:from-slate-200 dark:to-slate-300 text-white dark:text-slate-900 font-semibold">
              {userInitials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold truncate">{user.name || 'Пользователь'}</p>
            <p className="text-[11px] text-muted-foreground truncate">{user.email || ''}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

// ---- Dashboard Page ----

function DashboardPage({
  user,
  onNavigate,
  onCreateOrder,
  orders,
  isLoading,
}: {
  user: AuthUser
  onNavigate: (id: string) => void
  onCreateOrder: () => void
  orders: Order[]
  isLoading: boolean
}) {
  const [chartPeriod, setChartPeriod] = useState<'month' | 'week'>('month')

  if (isLoading) return <DashboardSkeleton />

  const orderStats = {
    new: orders.filter(o => o.status === 'new').length,
    inProgress: orders.filter(o => o.status === 'in_progress').length,
    done: orders.filter(o => o.status === 'done').length,
    total: orders.length,
  }

  const totalRevenue = orders
    .filter(o => o.estimatedCost)
    .reduce((sum, o) => sum + parseInt(o.estimatedCost!.replace(/\s/g, ''), 10), 0)
  const avgOrderValue = orders.filter(o => o.estimatedCost).length > 0
    ? Math.round(totalRevenue / orders.filter(o => o.estimatedCost).length)
    : 0

  const statCards = [
    { title: 'Новые заявки', value: String(orderStats.new), change: '+3', up: true, description: 'Требуют внимания', icon: ClipboardList, color: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-50 dark:bg-sky-950/40', gradient: 'from-sky-50/80 to-sky-100/40 dark:from-sky-950/40 dark:to-sky-900/20', progressColor: 'bg-sky-500', progress: 65 },
    { title: 'В работе', value: String(orderStats.inProgress), change: '2 мастера', up: true, description: 'Текущие заказы', icon: Wrench, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/40', gradient: 'from-amber-50/80 to-amber-100/40 dark:from-amber-950/40 dark:to-amber-900/20', progressColor: 'bg-amber-500', progress: 45 },
    { title: 'Выполнено', value: String(orderStats.done), change: '+1', up: true, description: 'За сегодня', icon: CheckCircle2, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-950/40', gradient: 'from-emerald-50/80 to-emerald-100/40 dark:from-emerald-950/40 dark:to-emerald-900/20', progressColor: 'bg-emerald-500', progress: 80 },
    { title: 'Всего заявок', value: String(orderStats.total), change: '+12%', up: true, description: 'За месяц', icon: BarChart3, color: 'text-violet-600 dark:text-violet-400', bg: 'bg-violet-50 dark:bg-violet-950/40', gradient: 'from-violet-50/80 to-violet-100/40 dark:from-violet-950/40 dark:to-violet-900/20', progressColor: 'bg-violet-500', progress: 55 },
  ]

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-3xl" role="img" aria-label="greeting">👋</span>
          <div>
            <h2 className="text-2xl lg:text-3xl font-bold tracking-tight">
              Добро пожаловать, {user.name || 'Администратор'}!
            </h2>
            <p className="text-muted-foreground mt-1">
              Обзор автосервиса «СавинцевАвтоЦентр» на сегодня
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="px-3 py-1 text-xs font-medium">
            <Calendar className="w-3 h-3 mr-1" />
            {new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}
          </Badge>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {statCards.map((stat, i) => {
          const Icon = stat.icon
          return (
            <div
              key={stat.title}
              className={`rounded-2xl border bg-gradient-to-br ${stat.gradient} bg-card p-5 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 group cursor-pointer relative overflow-hidden animate-in fade-in-0 slide-in-from-bottom-4`}
              style={{ animationDelay: `${i * 100}ms`, animationFillMode: 'both' }}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-medium text-muted-foreground">{stat.title}</span>
                <div className={`flex items-center justify-center w-9 h-9 rounded-xl ${stat.bg} group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`w-4 h-4 ${stat.color}`} />
                </div>
              </div>
              <div className="text-3xl font-bold tracking-tight">{stat.value}</div>
              <div className="flex items-center gap-1 mt-2">
                {stat.up ? (
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                )}
                <span className={`text-xs font-semibold ${stat.up ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                  {stat.change}
                </span>
                <span className="text-xs text-muted-foreground ml-1">{stat.description}</span>
              </div>
              <div className="mt-3 h-1.5 w-full rounded-full bg-muted/50 overflow-hidden">
                <div className={`h-full rounded-full ${stat.progressColor} transition-all duration-700`} style={{ width: `${stat.progress}%` }} />
              </div>
            </div>
          )
        })}
      </div>

      <div className="rounded-2xl border bg-card p-6 shadow-sm animate-in fade-in-0 slide-in-from-bottom-4 duration-500" style={{ animationDelay: '400ms', animationFillMode: 'both' }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/40">
              <CreditCard className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            </div>
            <div>
              <h3 className="font-semibold text-base">Выручка</h3>
              <p className="text-sm text-muted-foreground">Общий финансовый показатель</p>
            </div>
          </div>
          <Badge variant="secondary" className="text-xs">
            <TrendingUp className="w-3 h-3 mr-1" />+8%
          </Badge>
        </div>
        <div className="grid gap-6 sm:grid-cols-3">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Общая выручка</p>
            <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{totalRevenue.toLocaleString('ru-RU')} ₽</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Средний чек</p>
            <p className="text-2xl font-bold">{avgOrderValue.toLocaleString('ru-RU')} ₽</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Тренд</p>
            <div className="flex items-center gap-2">
              <div className="flex items-end gap-0.5 h-8">
                {[35, 55, 40, 65, 50, 70, 60].map((h, i) => (
                  <div key={i} className="w-2 bg-emerald-400/60 rounded-t" style={{ height: `${h}%` }} />
                ))}
              </div>
              <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">Рост</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-semibold text-base">Заявки по месяцам</h3>
              <p className="text-sm text-muted-foreground">Количество сервисных заказов</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setChartPeriod('month')} className={`px-2 py-1 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${chartPeriod === 'month' ? 'bg-primary text-primary-foreground' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>За месяц</button>
              <button onClick={() => setChartPeriod('week')} className={`px-2 py-1 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${chartPeriod === 'week' ? 'bg-primary text-primary-foreground' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>За неделю</button>
            </div>
          </div>
          <ChartContainer config={chartConfig} className="h-[250px] w-full">
            <BarChart data={chartPeriod === 'month' ? chartData : areaData.map(d => ({ month: d.day, visits: d.cpu, sessions: d.memory }))} barGap={4}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
              <YAxis tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="visits" fill="var(--color-visits)" radius={[6, 6, 0, 0]} maxBarSize={40} />
              <Bar dataKey="sessions" fill="var(--color-sessions)" radius={[6, 6, 0, 0]} maxBarSize={40} />
            </BarChart>
          </ChartContainer>
        </div>

        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-semibold text-base">Загрузка мастерских</h3>
              <p className="text-sm text-muted-foreground">Занятость постов за неделю</p>
            </div>
            <Badge variant="secondary" className="text-xs"><Zap className="w-3 h-3 mr-1" />Норма</Badge>
          </div>
          <ChartContainer config={areaConfig} className="h-[250px] w-full">
            <AreaChart data={areaData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="day" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
              <YAxis tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <defs>
                <linearGradient id="fillCpu" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--color-cpu)" stopOpacity={0.3} /><stop offset="95%" stopColor="var(--color-cpu)" stopOpacity={0} /></linearGradient>
                <linearGradient id="fillMemory" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--color-memory)" stopOpacity={0.3} /><stop offset="95%" stopColor="var(--color-memory)" stopOpacity={0} /></linearGradient>
              </defs>
              <Area dataKey="memory" type="monotone" fill="url(#fillMemory)" stroke="var(--color-memory)" strokeWidth={2} />
              <Area dataKey="cpu" type="monotone" fill="url(#fillCpu)" stroke="var(--color-cpu)" strokeWidth={2} />
            </AreaChart>
          </ChartContainer>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <h3 className="font-semibold text-base mb-4">Быстрые действия</h3>
          <div className="space-y-2">
            {[
              { label: 'Новая заявка', icon: Plus, desc: 'Оформить заказ-наряд', action: onCreateOrder },
              { label: 'Аналитика', icon: BarChart3, desc: 'Перейти к отчётам', action: () => onNavigate('analytics') },
              { label: 'Диагностика', icon: Database, desc: 'Проверка системы', action: () => toast.info('Система работает в штатном режиме') },
            ].map((action) => {
              const Icon = action.icon
              return (
                <button key={action.label} onClick={action.action} className="w-full flex items-center gap-3 p-3 rounded-xl border border-dashed hover:border-solid hover:bg-accent/50 transition-all duration-200 text-left group cursor-pointer hover:scale-[1.02] active:scale-[0.98]">
                  <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-accent group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-200">
                    <Icon className="w-4 h-4 transition-colors duration-200" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{action.label}</p>
                    <p className="text-[11px] text-muted-foreground">{action.desc}</p>
                  </div>
                </button>
              )
            })}
          </div>
        </div>

        <div className="lg:col-span-2 rounded-2xl border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-base">Последняя активность</h3>
            <Badge variant="outline" className="text-xs">Сегодня</Badge>
          </div>
          <ScrollArea className="h-[260px]">
            <div className="space-y-3">
              {mockActivity.slice(0, 5).map((entry) => {
                const typeStyles = {
                  create: 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300',
                  update: 'text-sky-700 dark:text-sky-300 bg-sky-100 dark:bg-sky-900/30',
                  delete: 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300',
                  login: 'bg-violet-100 dark:bg-violet-900/30 text-violet-700 dark:text-violet-300',
                }
                const typeLabels = { create: 'Создание', update: 'Обновление', delete: 'Удаление', login: 'Вход' }
                return (
                  <div key={entry.id} className="flex items-start gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center text-[10px] font-bold text-slate-700 dark:text-slate-200 shrink-0">
                      {getInitials(entry.user)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className={`text-[10px] font-semibold shrink-0 ${typeStyles[entry.type]}`}>{typeLabels[entry.type]}</Badge>
                      </div>
                      <p className="text-sm mt-0.5">
                        <span className="font-medium">{entry.user}</span>{' '}
                        <span className="text-muted-foreground">{entry.action.toLowerCase()}</span>{' '}
                        <span className="font-medium">{entry.target}</span>
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{entry.time}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  )
}

// ---- Orders Page ----

function OrdersPage({
  orders,
  setOrders,
  createOpen,
  setCreateOpen,
  isLoading,
}: {
  orders: Order[]
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>
  createOpen: boolean
  setCreateOpen: (open: boolean) => void
  isLoading: boolean
}) {
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [viewOpen, setViewOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formErrors, setFormErrors] = useState<Record<string, string>>({})

  const [form, setForm] = useState({
    clientName: '',
    clientPhone: '',
    carModel: '',
    carPlate: '',
    description: '',
    priority: 'normal' as OrderPriority,
    estimatedCost: '',
  })

  const [editForm, setEditForm] = useState({
    description: '',
    priority: 'normal' as OrderPriority,
    estimatedCost: '',
    status: 'new' as OrderStatus,
  })

  const resetForm = () => {
    setForm({ clientName: '', clientPhone: '', carModel: '', carPlate: '', description: '', priority: 'normal', estimatedCost: '' })
    setFormErrors({})
  }

  const resetEditForm = () => {
    setEditForm({ description: '', priority: 'normal', estimatedCost: '', status: 'new' })
    setFormErrors({})
  }

  const filteredOrders = orders.filter(o => {
    const matchesStatus = statusFilter === 'all' || o.status === statusFilter
    const matchesSearch = !searchQuery ||
      o.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.carModel.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.carPlate?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesStatus && matchesSearch
  })

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {}
    if (!form.clientName.trim()) errors.clientName = 'ФИО клиента обязательно'
    if (!form.clientPhone.trim()) errors.clientPhone = 'Телефон обязателен'
    if (!form.carModel.trim()) errors.carModel = 'Марка и модель обязательны'
    if (!form.description.trim()) errors.description = 'Описание работ обязательно'
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleCreate = async () => {
    if (!validateForm()) {
      toast.error('Заполните все обязательные поля')
      return
    }
    setIsSubmitting(true)
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Ошибка создания')
      }
      const { order } = await res.json()
      setOrders(prev => [order, ...prev])
      setCreateOpen(false)
      resetForm()
      toast.success('Заявка создана', { description: `${form.clientName} — ${form.carModel}` })
    } catch (err) {
      toast.error('Ошибка создания заявки', { description: err instanceof Error ? err.message : 'Попробуйте позже' })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleStatusChange = async (order: Order, newStatus: OrderStatus) => {
    try {
      const res = await fetch(`/api/orders/${order.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      })
      if (!res.ok) throw new Error('Ошибка обновления')
      const { order: updated } = await res.json()
      setOrders(prev => prev.map(o => o.id === order.id ? updated : o))
      toast.success('Статус обновлён', { description: `Заявка → ${statusConfig[newStatus].label}` })
    } catch {
      toast.error('Ошибка обновления статуса')
    }
  }

  const handleDelete = async () => {
    if (!selectedOrder) return
    try {
      const res = await fetch(`/api/orders/${selectedOrder.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Ошибка удаления')
      setOrders(prev => prev.filter(o => o.id !== selectedOrder.id))
      setDeleteOpen(false)
      toast.success('Заявка удалена', { description: `${selectedOrder.clientName} — ${selectedOrder.carModel}` })
      setSelectedOrder(null)
    } catch {
      toast.error('Ошибка удаления заявки')
    }
  }

  const handleEditOpen = (order: Order) => {
    setSelectedOrder(order)
    setEditForm({
      description: order.description,
      priority: order.priority,
      estimatedCost: order.estimatedCost || '',
      status: order.status,
    })
    setEditOpen(true)
  }

  const handleEditSave = async () => {
    if (!selectedOrder) return
    try {
      const res = await fetch(`/api/orders/${selectedOrder.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: editForm.description,
          priority: editForm.priority,
          estimatedCost: editForm.estimatedCost || null,
        }),
      })
      if (!res.ok) throw new Error('Ошибка обновления')
      const { order: updated } = await res.json()
      setOrders(prev => prev.map(o => o.id === selectedOrder.id ? updated : o))
      setEditOpen(false)
      toast.success('Заявка обновлена', { description: `${selectedOrder.clientName}` })
    } catch {
      toast.error('Ошибка обновления заявки')
    }
  }

  const handleExportCSV = () => {
    const headers = ['ID', 'Клиент', 'Телефон', 'Авто', 'Гос. номер', 'Описание', 'Статус', 'Приоритет', 'Стоимость', 'Мастер', 'Создана', 'Обновлена']
    const rows = orders.map(o => [
      o.id,
      o.clientName,
      o.clientPhone,
      o.carModel,
      o.carPlate || '',
      o.description.replace(/"/g, '""'),
      statusConfig[o.status].label,
      priorityConfig[o.priority].label,
      o.estimatedCost || '',
      o.assignedTo || '',
      formatDate(o.createdAt),
      formatDate(o.updatedAt),
    ])
    const csv = [headers, ...rows].map(r => r.map(c => `"${c}"`).join(',')).join('\n')
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `orders_${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('CSV экспортирован', { description: `${orders.length} заявок` })
  }

  const handlePrint = (order: Order) => {
    const content = `
      <html><head><title>Заявка #${order.id.slice(0, 8)}</title>
      <style>body{font-family:Arial,sans-serif;padding:40px;color:#1e293b}
      h1{font-size:20px;margin-bottom:16px}table{width:100%;border-collapse:collapse}
      td,th{padding:8px 12px;border:1px solid #e2e8f0;text-align:left;font-size:14px}
      th{background:#f1f5f9;font-weight:600}.status{padding:4px 8px;border-radius:4px;font-size:12px}
      .footer{margin-top:32px;font-size:12px;color:#94a3b8}</style></head>
      <body><h1>Заказ-наряд #${order.id.slice(0, 8)}</h1>
      <table><tr><th>Клиент</th><td>${order.clientName}</td></tr>
      <tr><th>Телефон</th><td>${order.clientPhone}</td></tr>
      <tr><th>Автомобиль</th><td>${order.carModel}${order.carPlate ? ' (' + order.carPlate + ')' : ''}</td></tr>
      <tr><th>Статус</th><td>${statusConfig[order.status].label}</td></tr>
      <tr><th>Приоритет</th><td>${priorityConfig[order.priority].label}</td></tr>
      <tr><th>Описание</th><td>${order.description}</td></tr>
      ${order.estimatedCost ? `<tr><th>Стоимость</th><td>~${order.estimatedCost} ₽</td></tr>` : ''}
      ${order.assignedTo ? `<tr><th>Мастер</th><td>${order.assignedTo}</td></tr>` : ''}
      <tr><th>Создана</th><td>${formatDate(order.createdAt)}</td></tr>
      <tr><th>Обновлена</th><td>${formatDate(order.updatedAt)}</td></tr></table>
      <p class="footer">СавинцевАвтоЦентр · ${new Date().toLocaleDateString('ru-RU')}</p></body></html>`
    const w = window.open('', '_blank')
    if (w) { w.document.write(content); w.document.close(); w.print() }
  }

  const statusCounts = {
    all: orders.length,
    new: orders.filter(o => o.status === 'new').length,
    in_progress: orders.filter(o => o.status === 'in_progress').length,
    waiting: orders.filter(o => o.status === 'waiting').length,
    done: orders.filter(o => o.status === 'done').length,
  }

  if (isLoading) return <OrdersSkeleton />

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Заявки</h2>
          <p className="text-muted-foreground mt-1">Управление заказ-нарядами автосервиса</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="rounded-xl cursor-pointer" onClick={handleExportCSV}>
            <Download className="w-4 h-4 mr-2" />Экспорт CSV
          </Button>
          <Button className="rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer" onClick={() => setCreateOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />Новая заявка
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Поиск по клиенту, авто, описанию..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9 rounded-xl" />
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <Filter className="w-4 h-4 text-muted-foreground shrink-0" />
          {[
            { key: 'all', label: 'Все' },
            { key: 'new', label: 'Новые' },
            { key: 'in_progress', label: 'В работе' },
            { key: 'waiting', label: 'Ожидание' },
            { key: 'done', label: 'Готово' },
          ].map(({ key, label }) => (
            <button key={key} onClick={() => setStatusFilter(key)} className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${statusFilter === key ? 'bg-primary text-primary-foreground shadow-sm' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>
              {label}
              <span className={`text-[10px] ${statusFilter === key ? 'text-primary-foreground/70' : 'text-muted-foreground/60'}`}>
                {statusCounts[key as keyof typeof statusCounts] || 0}
              </span>
            </button>
          ))}
        </div>
      </div>

      {filteredOrders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center mb-4">
            <ClipboardList className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold">Заявок не найдено</h3>
          <p className="text-sm text-muted-foreground mt-1">Попробуйте изменить фильтры или создайте новую заявку</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredOrders.map((order, i) => {
            const StatusIcon = statusConfig[order.status].icon
            return (
              <div key={order.id} className={`rounded-2xl border-l-4 ${statusBorderColor[order.status]} border bg-card p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 group animate-in fade-in-0 slide-in-from-bottom-2`} style={{ animationDelay: `${i * 50}ms`, animationFillMode: 'both' }}>
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  <div className="flex items-center gap-2 lg:w-32 shrink-0">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge className={`text-[10px] font-semibold ${statusConfig[order.status].bg} ${statusConfig[order.status].color} border-0 cursor-help`}>
                          <StatusIcon className="w-3 h-3 mr-1" />{statusConfig[order.status].label}
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent side="bottom" className="max-w-[200px]">
                        <p className="text-xs">{statusConfig[order.status].description}</p>
                      </TooltipContent>
                    </Tooltip>
                    {order.priority !== 'normal' && (
                      <Badge className={`text-[10px] font-semibold ${priorityConfig[order.priority].bg} ${priorityConfig[order.priority].color} border-0`}>
                        {order.priority === 'urgent' && <AlertTriangle className="w-3 h-3 mr-0.5" />}
                        {priorityConfig[order.priority].label}
                      </Badge>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm">{order.clientName}</span>
                      <span className="text-muted-foreground">·</span>
                      <span className="text-sm text-muted-foreground flex items-center gap-1"><Car className="w-3 h-3" />{order.carModel}</span>
                      {order.carPlate && <Badge variant="outline" className="text-[10px] font-mono h-5">{order.carPlate}</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{order.description}</p>
                    <div className="flex items-center gap-3 mt-2 text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{order.clientPhone}</span>
                      {order.estimatedCost && <span className="font-medium text-emerald-600 dark:text-emerald-400">~{order.estimatedCost} ₽</span>}
                      {order.assignedTo && <span>Мастер: {order.assignedTo}</span>}
                      <span className="ml-auto">{timeAgo(order.createdAt)}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 cursor-pointer" onClick={() => { setSelectedOrder(order); setViewOpen(true) }}><Eye className="w-4 h-4" /></Button></TooltipTrigger><TooltipContent>Просмотр</TooltipContent></Tooltip>
                    <Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 cursor-pointer" onClick={() => handleEditOpen(order)}><Edit className="w-4 h-4" /></Button></TooltipTrigger><TooltipContent>Редактировать</TooltipContent></Tooltip>
                    {order.status !== 'done' && order.status !== 'cancelled' && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 cursor-pointer"><MoreHorizontal className="w-4 h-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="rounded-xl">
                          {order.status === 'new' && <DropdownMenuItem className="cursor-pointer" onClick={() => handleStatusChange(order, 'in_progress')}><Wrench className="mr-2 h-4 w-4" />Взять в работу</DropdownMenuItem>}
                          {order.status === 'in_progress' && (
                            <>
                              <DropdownMenuItem className="cursor-pointer" onClick={() => handleStatusChange(order, 'waiting')}><Clock className="mr-2 h-4 w-4" />На ожидание</DropdownMenuItem>
                              <DropdownMenuItem className="cursor-pointer" onClick={() => handleStatusChange(order, 'done')}><CheckCircle2 className="mr-2 h-4 w-4" />Завершить</DropdownMenuItem>
                            </>
                          )}
                          {order.status === 'waiting' && <DropdownMenuItem className="cursor-pointer" onClick={() => handleStatusChange(order, 'in_progress')}><Wrench className="mr-2 h-4 w-4" />Возобновить</DropdownMenuItem>}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="cursor-pointer text-destructive" onClick={() => { setSelectedOrder(order); setDeleteOpen(true) }}><Trash2 className="mr-2 h-4 w-4" />Удалить</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Create Order Dialog */}
      <Dialog open={createOpen} onOpenChange={(open) => { setCreateOpen(open); if (!open) resetForm() }}>
        <DialogContent className="sm:max-w-[600px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><ClipboardList className="w-5 h-5" />Новая заявка</DialogTitle>
            <DialogDescription>Оформите новый заказ-наряд для автосервиса</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="client-name">ФИО клиента *</Label>
                <Input id="client-name" placeholder="Иванов Иван Иванович" value={form.clientName} onChange={(e) => { setForm(f => ({ ...f, clientName: e.target.value })); if (formErrors.clientName) setFormErrors(prev => { const n = { ...prev }; delete n.clientName; return n }) }} className={`rounded-xl ${formErrors.clientName ? 'border-red-500 focus-visible:ring-red-500' : ''}`} />
                {formErrors.clientName && <p className="text-xs text-red-500">{formErrors.clientName}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="client-phone">Телефон *</Label>
                <Input id="client-phone" placeholder="+7 (___) ___-__-__" value={form.clientPhone} onChange={(e) => { setForm(f => ({ ...f, clientPhone: e.target.value })); if (formErrors.clientPhone) setFormErrors(prev => { const n = { ...prev }; delete n.clientPhone; return n }) }} className={`rounded-xl ${formErrors.clientPhone ? 'border-red-500 focus-visible:ring-red-500' : ''}`} />
                {formErrors.clientPhone && <p className="text-xs text-red-500">{formErrors.clientPhone}</p>}
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="car-model">Марка и модель авто *</Label>
                <Input id="car-model" placeholder="Toyota Camry" value={form.carModel} onChange={(e) => { setForm(f => ({ ...f, carModel: e.target.value })); if (formErrors.carModel) setFormErrors(prev => { const n = { ...prev }; delete n.carModel; return n }) }} className={`rounded-xl ${formErrors.carModel ? 'border-red-500 focus-visible:ring-red-500' : ''}`} />
                {formErrors.carModel && <p className="text-xs text-red-500">{formErrors.carModel}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="car-plate">Гос. номер</Label>
                <Input id="car-plate" placeholder="А123МН77" value={form.carPlate} onChange={(e) => setForm(f => ({ ...f, carPlate: e.target.value }))} className="rounded-xl" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Описание работ *</Label>
              <Textarea id="description" placeholder="Опишите проблему или необходимые работы..." value={form.description} onChange={(e) => { setForm(f => ({ ...f, description: e.target.value })); if (formErrors.description) setFormErrors(prev => { const n = { ...prev }; delete n.description; return n }) }} className={`rounded-xl min-h-[80px] resize-none ${formErrors.description ? 'border-red-500 focus-visible:ring-red-500' : ''}`} />
              {formErrors.description && <p className="text-xs text-red-500">{formErrors.description}</p>}
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Приоритет</Label>
                <Select value={form.priority} onValueChange={(v) => setForm(f => ({ ...f, priority: v as OrderPriority }))}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="low">Низкий</SelectItem><SelectItem value="normal">Обычный</SelectItem><SelectItem value="high">Высокий</SelectItem><SelectItem value="urgent">Срочный</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="estimated-cost">Ориентировочная стоимость (₽)</Label>
                <Input id="estimated-cost" placeholder="10 000" value={form.estimatedCost} onChange={(e) => setForm(f => ({ ...f, estimatedCost: e.target.value }))} className="rounded-xl" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-xl cursor-pointer" onClick={() => { setCreateOpen(false); resetForm() }}>Отмена</Button>
            <Button className="rounded-xl cursor-pointer" onClick={handleCreate} disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Создать
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Order Dialog */}
      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="sm:max-w-[600px] rounded-2xl">
          {selectedOrder && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  Заявка #{selectedOrder.id.slice(0, 8)}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge className={`text-[10px] font-semibold cursor-help ${statusConfig[selectedOrder.status].bg} ${statusConfig[selectedOrder.status].color} border-0`}>
                        {statusConfig[selectedOrder.status].label}
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent side="bottom"><p className="text-xs">{statusConfig[selectedOrder.status].description}</p></TooltipContent>
                  </Tooltip>
                </DialogTitle>
                <DialogDescription>Подробности заказ-наряда</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="grid gap-3">
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-accent/50">
                    <Users className="w-4 h-4 mt-0.5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">{selectedOrder.clientName}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Phone className="w-3 h-3" />{selectedOrder.clientPhone}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-accent/50">
                    <Car className="w-4 h-4 mt-0.5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">{selectedOrder.carModel} {selectedOrder.carPlate && <Badge variant="outline" className="text-[10px] font-mono ml-1">{selectedOrder.carPlate}</Badge>}</p>
                    </div>
                  </div>
                </div>
                <Separator />
                {/* Timeline */}
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Ход выполнения</p>
                  <div className="flex items-center gap-2">
                    {(['new', 'in_progress', 'waiting', 'done'] as OrderStatus[]).map((s, i) => {
                      const currentIdx = ['new', 'in_progress', 'waiting', 'done'].indexOf(selectedOrder.status)
                      const isCompleted = i <= currentIdx && selectedOrder.status !== 'cancelled'
                      const isCurrent = s === selectedOrder.status && selectedOrder.status !== 'cancelled'
                      return (
                        <div key={s} className="flex items-center gap-2 flex-1">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${isCompleted ? 'bg-emerald-500 text-white' : 'bg-muted text-muted-foreground'}`}>
                            {isCompleted ? '✓' : i + 1}
                          </div>
                          <span className={`text-[10px] ${isCurrent ? 'font-bold text-foreground' : 'text-muted-foreground'}`}>{statusConfig[s].label}</span>
                          {i < 3 && <div className={`flex-1 h-0.5 ${isCompleted && i < currentIdx ? 'bg-emerald-500' : 'bg-muted'}`} />}
                        </div>
                      )
                    })}
                  </div>
                </div>
                <Separator />
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-1 uppercase tracking-wider">Описание работ</p>
                  <p className="text-sm">{selectedOrder.description}</p>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">Приоритет</p>
                    <Badge className={`text-[10px] font-semibold mt-1 ${priorityConfig[selectedOrder.priority].bg} ${priorityConfig[selectedOrder.priority].color} border-0`}>{priorityConfig[selectedOrder.priority].label}</Badge>
                  </div>
                  {selectedOrder.estimatedCost && (
                    <div>
                      <p className="text-xs text-muted-foreground">Стоимость</p>
                      <p className="font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5">~{selectedOrder.estimatedCost} ₽</p>
                    </div>
                  )}
                  <div><p className="text-xs text-muted-foreground">Создана</p><p className="mt-0.5">{formatDate(selectedOrder.createdAt)}</p></div>
                  <div><p className="text-xs text-muted-foreground">Обновлена</p><p className="mt-0.5">{formatDate(selectedOrder.updatedAt)}</p></div>
                </div>
                {selectedOrder.assignedTo && (
                  <div className="p-3 rounded-xl border"><p className="text-xs text-muted-foreground mb-1">Мастер</p><p className="text-sm font-medium">{selectedOrder.assignedTo}</p></div>
                )}
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" className="rounded-xl cursor-pointer" onClick={() => handlePrint(selectedOrder)}>
                  <Printer className="w-4 h-4 mr-2" />Печать
                </Button>
                <Button variant="outline" className="rounded-xl cursor-pointer" onClick={() => { setViewOpen(false); handleEditOpen(selectedOrder) }}>
                  <Edit className="w-4 h-4 mr-2" />Редактировать
                </Button>
                {selectedOrder.status === 'new' && (
                  <Button className="rounded-xl cursor-pointer" onClick={() => { handleStatusChange(selectedOrder, 'in_progress'); setViewOpen(false) }}><Wrench className="w-4 h-4 mr-2" />Взять в работу</Button>
                )}
                {selectedOrder.status === 'in_progress' && (
                  <Button className="rounded-xl cursor-pointer" onClick={() => { handleStatusChange(selectedOrder, 'done'); setViewOpen(false) }}><CheckCircle2 className="w-4 h-4 mr-2" />Завершить</Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Order Dialog */}
      <Dialog open={editOpen} onOpenChange={(open) => { setEditOpen(open); if (!open) resetEditForm() }}>
        <DialogContent className="sm:max-w-[500px] rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Edit className="w-5 h-5" />Редактирование заявки</DialogTitle>
            <DialogDescription>Измените описание, приоритет и стоимость</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="edit-description">Описание работ</Label>
              <Textarea id="edit-description" value={editForm.description} onChange={(e) => setEditForm(f => ({ ...f, description: e.target.value }))} className="rounded-xl min-h-[80px] resize-none" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Приоритет</Label>
                <Select value={editForm.priority} onValueChange={(v) => setEditForm(f => ({ ...f, priority: v as OrderPriority }))}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="low">Низкий</SelectItem><SelectItem value="normal">Обычный</SelectItem><SelectItem value="high">Высокий</SelectItem><SelectItem value="urgent">Срочный</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-cost">Ориентировочная стоимость (₽)</Label>
                <Input id="edit-cost" value={editForm.estimatedCost} onChange={(e) => setEditForm(f => ({ ...f, estimatedCost: e.target.value }))} className="rounded-xl" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-xl cursor-pointer" onClick={() => setEditOpen(false)}>Отмена</Button>
            <Button className="rounded-xl cursor-pointer" onClick={handleEditSave}>Сохранить</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить заявку?</AlertDialogTitle>
            <AlertDialogDescription>
              Заявка от {selectedOrder?.clientName} ({selectedOrder?.carModel}) будет удалена без возможности восстановления.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl cursor-pointer">Отмена</AlertDialogCancel>
            <AlertDialogAction className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90 cursor-pointer" onClick={handleDelete}>Удалить</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ---- Clients Page ----

function ClientsPage({ orders }: { orders: Order[] }) {
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState<'name' | 'lastVisit' | 'totalOrders'>('name')

  // Derive clients from orders
  const clientMap = orders.reduce((acc, o) => {
    const key = o.clientPhone
    if (!acc[key]) {
      acc[key] = { id: key, name: o.clientName, phone: o.clientPhone, carModel: o.carModel, lastVisit: o.createdAt, totalOrders: 0 }
    }
    acc[key].totalOrders++
    if (new Date(o.createdAt) > new Date(acc[key].lastVisit)) {
      acc[key].lastVisit = o.createdAt
      acc[key].carModel = o.carModel
    }
    return acc
  }, {} as Record<string, Client>)

  const clients = Object.values(clientMap)

  const filteredClients = clients
    .filter(c =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      c.carModel.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name, 'ru')
      if (sortBy === 'lastVisit') return new Date(b.lastVisit).getTime() - new Date(a.lastVisit).getTime()
      return b.totalOrders - a.totalOrders
    })

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Клиенты</h2>
        <p className="text-muted-foreground mt-1">База клиентов автосервиса</p>
      </div>
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Поиск по имени, телефону, авто..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9 rounded-xl" />
        </div>
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
          <SelectTrigger className="w-[180px] rounded-xl"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="name">По имени</SelectItem><SelectItem value="lastVisit">По последнему визиту</SelectItem><SelectItem value="totalOrders">По кол-ву заказов</SelectItem></SelectContent>
        </Select>
      </div>
      <div className="grid gap-4">
        {filteredClients.map((client, i) => (
          <div key={client.id} className="rounded-2xl border bg-card p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 animate-in fade-in-0 slide-in-from-bottom-2" style={{ animationDelay: `${i * 50}ms`, animationFillMode: 'both' }}>
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center text-sm font-bold text-slate-700 dark:text-slate-200 shrink-0">{getInitials(client.name)}</div>
                <div className="min-w-0">
                  <p className="font-semibold text-sm truncate">{client.name}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Phone className="w-3 h-3" />{client.phone}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 sm:ml-auto text-sm">
                <div className="flex items-center gap-1.5 text-muted-foreground"><Car className="w-3.5 h-3.5" /><span>{client.carModel}</span></div>
                <div className="flex items-center gap-1.5 text-muted-foreground"><Calendar className="w-3.5 h-3.5" /><span>{timeAgo(client.lastVisit)}</span></div>
                <Badge variant="secondary" className="text-[10px]"><ClipboardList className="w-3 h-3 mr-0.5" />{client.totalOrders} заказов</Badge>
              </div>
            </div>
          </div>
        ))}
      </div>
      {filteredClients.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center mb-4"><Users className="w-8 h-8 text-muted-foreground" /></div>
          <h3 className="text-lg font-semibold">Клиентов не найдено</h3>
          <p className="text-sm text-muted-foreground mt-1">Попробуйте изменить параметры поиска</p>
        </div>
      )}
    </div>
  )
}

// ---- Analytics Page ----

function AnalyticsPage({ orders, isLoading }: { orders: Order[]; isLoading: boolean }) {
  const [dateRange, setDateRange] = useState<'7' | '30' | 'all'>('30')
  const [stats, setStats] = useState<OrderStats | null>(null)

  useEffect(() => {
    async function fetchStats() {
      try {
        const res = await fetch('/api/orders/stats')
        if (res.ok) {
          const data = await res.json()
          setStats(data)
        }
      } catch {
        // silently fail
      }
    }
    fetchStats()
  }, [orders])

  if (isLoading) return <OrdersSkeleton />

  const filteredOrders = dateRange === 'all' ? orders : orders.filter(o => {
    const days = parseInt(dateRange)
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000)
    return new Date(o.createdAt) >= cutoff
  })

  // Revenue by month from filtered orders
  const revenueByMonth: Record<string, number> = {}
  for (const order of filteredOrders.filter(o => o.estimatedCost)) {
    const month = new Date(order.createdAt).toLocaleDateString('ru-RU', { year: 'numeric', month: 'short' })
    revenueByMonth[month] = (revenueByMonth[month] || 0) + parseInt(order.estimatedCost!.replace(/\s/g, ''), 10)
  }
  const revenueChartData = Object.entries(revenueByMonth).map(([month, revenue]) => ({ month, revenue }))

  // Status distribution
  const statusChartData = Object.entries(
    filteredOrders.reduce((acc, o) => { acc[o.status] = (acc[o.status] || 0) + 1; return acc }, {} as Record<string, number>)
  ).map(([status, count]) => ({ status, count, label: statusConfig[status as OrderStatus]?.label || status }))

  const PIE_COLORS = ['#0ea5e9', '#f59e0b', '#8b5cf6', '#10b981', '#ef4444']

  const totalRevenue = filteredOrders.filter(o => o.estimatedCost).reduce((sum, o) => sum + parseInt(o.estimatedCost!.replace(/\s/g, ''), 10), 0)
  const avgCheck = filteredOrders.filter(o => o.estimatedCost).length > 0
    ? Math.round(totalRevenue / filteredOrders.filter(o => o.estimatedCost).length)
    : 0
  const doneCount = filteredOrders.filter(o => o.status === 'done').length
  const completionRate = filteredOrders.length > 0 ? Math.round((doneCount / filteredOrders.length) * 100) : 0
  const daysInRange = dateRange === 'all' ? 365 : parseInt(dateRange)
  const ordersPerDay = Math.round((filteredOrders.length / daysInRange) * 10) / 10

  const revenueChartConfig = { revenue: { label: 'Выручка', color: 'var(--color-chart-1)' } }
  const pieChartConfig = statusChartData.reduce((acc, d, i) => { acc[d.status] = { label: d.label, color: PIE_COLORS[i] }; return acc }, {} as Record<string, { label: string; color: string }>)

  // Top clients from filtered orders
  const clientMap: Record<string, { name: string; orders: number; totalSpent: number }> = {}
  for (const order of filteredOrders) {
    const key = order.clientPhone
    if (!clientMap[key]) clientMap[key] = { name: order.clientName, orders: 0, totalSpent: 0 }
    clientMap[key].orders++
    if (order.estimatedCost) clientMap[key].totalSpent += parseInt(order.estimatedCost.replace(/\s/g, ''), 10)
  }
  const topClients = Object.values(clientMap).sort((a, b) => b.orders - a.orders)

  // Car models from filtered orders
  const carModelMap: Record<string, number> = {}
  for (const order of filteredOrders) {
    carModelMap[order.carModel] = (carModelMap[order.carModel] || 0) + 1
  }
  const carModels = Object.entries(carModelMap).map(([model, count]) => ({ model, count })).sort((a, b) => b.count - a.count)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Аналитика</h2>
          <p className="text-muted-foreground mt-1">Отчёты и статистика автосервиса</p>
        </div>
        <div className="flex items-center gap-2">
          {[
            { key: '7' as const, label: '7 дней' },
            { key: '30' as const, label: '30 дней' },
            { key: 'all' as const, label: 'Все время' },
          ].map(({ key, label }) => (
            <button key={key} onClick={() => setDateRange(key)} className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${dateRange === key ? 'bg-primary text-primary-foreground shadow-sm' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { title: 'Общая выручка', value: `${totalRevenue.toLocaleString('ru-RU')} ₽`, icon: DollarSign, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-950/40' },
          { title: 'Средний чек', value: `${avgCheck.toLocaleString('ru-RU')} ₽`, icon: CreditCard, color: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-50 dark:bg-sky-950/40' },
          { title: 'Заявок в день', value: String(ordersPerDay), icon: Target, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/40' },
          { title: 'Процент выполнения', value: `${completionRate}%`, icon: Timer, color: 'text-violet-600 dark:text-violet-400', bg: 'bg-violet-50 dark:bg-violet-950/40' },
        ].map((metric, i) => {
          const Icon = metric.icon
          return (
            <div key={metric.title} className="rounded-2xl border bg-card p-5 shadow-sm hover:shadow-md transition-all duration-300 animate-in fade-in-0 slide-in-from-bottom-4" style={{ animationDelay: `${i * 100}ms`, animationFillMode: 'both' }}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">{metric.title}</span>
                <div className={`flex items-center justify-center w-9 h-9 rounded-xl ${metric.bg}`}><Icon className={`w-4 h-4 ${metric.color}`} /></div>
              </div>
              <div className="text-2xl font-bold">{metric.value}</div>
            </div>
          )
        })}
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Revenue Line Chart */}
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <h3 className="font-semibold text-base mb-1">Выручка по месяцам</h3>
          <p className="text-sm text-muted-foreground mb-4">Динамика доходов автосервиса</p>
          {revenueChartData.length > 0 ? (
            <ChartContainer config={revenueChartConfig} className="h-[280px] w-full">
              <LineChart data={revenueChartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
                <YAxis tickLine={false} axisLine={false} tickMargin={8} fontSize={12} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="revenue" stroke="var(--color-revenue)" strokeWidth={2} dot={{ r: 4, fill: 'var(--color-revenue)' }} />
              </LineChart>
            </ChartContainer>
          ) : (
            <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">Нет данных за выбранный период</div>
          )}
        </div>

        {/* Status Pie Chart */}
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <h3 className="font-semibold text-base mb-1">Распределение по статусам</h3>
          <p className="text-sm text-muted-foreground mb-4">Доля заявок в каждом статусе</p>
          {statusChartData.length > 0 ? (
            <div className="flex items-center gap-4">
              <ChartContainer config={pieChartConfig} className="h-[250px] w-[250px]">
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Pie data={statusChartData} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={90} innerRadius={50} strokeWidth={2}>
                    {statusChartData.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
              <div className="space-y-2">
                {statusChartData.map((d, i) => (
                  <div key={d.status} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }} />
                    <span className="text-sm">{d.label}</span>
                    <span className="text-sm text-muted-foreground ml-auto">{d.count}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">Нет данных</div>
          )}
        </div>
      </div>

      {/* Tables */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Top Clients */}
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <h3 className="font-semibold text-base mb-4">Топ клиентов</h3>
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {topClients.length > 0 ? topClients.slice(0, 10).map((c, i) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 dark:from-slate-700 dark:to-slate-600 flex items-center justify-center text-[10px] font-bold text-slate-700 dark:text-slate-200 shrink-0">{getInitials(c.name)}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{c.name}</p>
                  <p className="text-[11px] text-muted-foreground">{c.orders} заказов · {c.totalSpent.toLocaleString('ru-RU')} ₽</p>
                </div>
              </div>
            )) : <p className="text-sm text-muted-foreground text-center py-4">Нет данных</p>}
          </div>
        </div>

        {/* Car Models Breakdown */}
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <h3 className="font-semibold text-base mb-4">Марки автомобилей</h3>
          <ChartContainer config={{ count: { label: 'Кол-во', color: 'var(--color-chart-1)' } }} className="h-[280px] w-full">
            <BarChart data={carModels} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" tickLine={false} axisLine={false} fontSize={12} />
              <YAxis dataKey="model" type="category" tickLine={false} axisLine={false} fontSize={12} width={120} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="count" fill="var(--color-count)" radius={[0, 6, 6, 0]} maxBarSize={30} />
            </BarChart>
          </ChartContainer>
        </div>
      </div>

      {/* Average Completion Time */}
      {stats && stats.avgCompletionHours > 0 && (
        <div className="rounded-2xl border bg-card p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-violet-50 dark:bg-violet-950/40">
              <Timer className="w-5 h-5 text-violet-600 dark:text-violet-400" />
            </div>
            <div>
              <h3 className="font-semibold text-base">Среднее время выполнения</h3>
              <p className="text-sm text-muted-foreground">От создания до завершения заявки</p>
            </div>
          </div>
          <div className="flex items-end gap-3">
            <span className="text-4xl font-bold text-violet-600 dark:text-violet-400">{stats.avgCompletionHours}</span>
            <span className="text-lg text-muted-foreground mb-1">часов</span>
          </div>
        </div>
      )}
    </div>
  )
}

// ---- Settings Page ----

function SettingsPage() {
  const [twoFactor, setTwoFactor] = useState(false)
  const [emailNotif, setEmailNotif] = useState(true)
  const [maintenance, setMaintenance] = useState(false)
  const [clearDataOpen, setClearDataOpen] = useState(false)
  const [resetSettingsOpen, setResetSettingsOpen] = useState(false)
  const [siteName, setSiteName] = useState('СавинцевАвтоЦентр')
  const [adminEmail, setAdminEmail] = useState('admin@savincevac.ru')
  const [timezone, setTimezone] = useState('Europe/Moscow (UTC+3)')
  const [siteNameError, setSiteNameError] = useState('')
  const [isSaving, setIsSaving] = useState(false)

  // Load settings from API
  useEffect(() => {
    async function loadSettings() {
      try {
        const res = await fetch('/api/settings')
        if (res.ok) {
          const { settings } = await res.json()
          if (settings.siteName) setSiteName(settings.siteName)
          if (settings.adminEmail) setAdminEmail(settings.adminEmail)
          if (settings.timezone) setTimezone(settings.timezone)
          if (settings.twoFactor !== undefined) setTwoFactor(settings.twoFactor === 'true')
          if (settings.emailNotifications !== undefined) setEmailNotif(settings.emailNotifications === 'true')
          if (settings.maintenanceMode !== undefined) setMaintenance(settings.maintenanceMode === 'true')
        }
      } catch {
        // use defaults
      }
    }
    loadSettings()
  }, [])

  const handleSaveSettings = async () => {
    if (!siteName.trim()) {
      setSiteNameError('Название системы не может быть пустым')
      return
    }
    setSiteNameError('')
    setIsSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            siteName,
            adminEmail,
            timezone,
            twoFactor: String(twoFactor),
            emailNotifications: String(emailNotif),
            maintenanceMode: String(maintenance),
          }
        }),
      })
      if (!res.ok) throw new Error('Ошибка')
      toast.success('Настройки сохранены')
    } catch {
      toast.error('Ошибка сохранения настроек')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Настройки</h2>
        <p className="text-muted-foreground mt-1">Конфигурация системы и безопасности</p>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border bg-card p-6 shadow-sm space-y-6">
          <div className="flex items-center gap-2"><Globe className="w-4 h-4 text-muted-foreground" /><div><h3 className="font-semibold text-base">Общие</h3><p className="text-sm text-muted-foreground">Основные параметры системы</p></div></div>
          <Separator />
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="site-name">Название системы</Label>
              <Input id="site-name" value={siteName} onChange={(e) => { setSiteName(e.target.value); if (siteNameError) setSiteNameError('') }} className={`rounded-xl ${siteNameError ? 'border-red-500 focus-visible:ring-red-500' : ''}`} />
              {siteNameError && <p className="text-xs text-red-500">{siteNameError}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="admin-email">Email администратора</Label>
              <Input id="admin-email" type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="timezone">Часовой пояс</Label>
              <Input id="timezone" value={timezone} onChange={(e) => setTimezone(e.target.value)} className="rounded-xl" />
            </div>
          </div>
          <Button className="w-full rounded-xl cursor-pointer" onClick={handleSaveSettings} disabled={isSaving}>
            {isSaving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Сохранить изменения
          </Button>
        </div>

        <div className="rounded-2xl border bg-card p-6 shadow-sm space-y-6">
          <div className="flex items-center gap-2"><Lock className="w-4 h-4 text-muted-foreground" /><div><h3 className="font-semibold text-base">Безопасность</h3><p className="text-sm text-muted-foreground">Настройки защиты и доступа</p></div></div>
          <Separator />
          <div className="space-y-5">
            <div className="flex items-center justify-between cursor-pointer">
              <div className="space-y-0.5"><Label className="cursor-pointer">Двухфакторная аутентификация</Label><p className="text-xs text-muted-foreground">Дополнительный уровень защиты</p></div>
              <Switch checked={twoFactor} onCheckedChange={setTwoFactor} />
            </div>
            <div className="flex items-center justify-between cursor-pointer">
              <div className="space-y-0.5"><Label className="cursor-pointer">Email уведомления</Label><p className="text-xs text-muted-foreground">Оповещения о входе в аккаунт</p></div>
              <Switch checked={emailNotif} onCheckedChange={setEmailNotif} />
            </div>
            <div className="flex items-center justify-between cursor-pointer">
              <div className="space-y-0.5"><Label className="cursor-pointer">Режим обслуживания</Label><p className="text-xs text-muted-foreground">Ограничить доступ к системе</p></div>
              <Switch checked={maintenance} onCheckedChange={setMaintenance} />
            </div>
          </div>
          <Separator />
          <div className="space-y-3">
            <Label>Срок действия JWT токена</Label>
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-muted-foreground"><span>1 день</span><span>7 дней</span><span>30 дней</span></div>
              <Progress value={25} className="h-2" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 rounded-2xl border-2 border-dashed border-destructive/30 bg-destructive/5 p-6 space-y-4">
          <div className="flex items-start gap-3"><AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" /><div><h3 className="font-semibold text-base text-destructive">Опасная зона</h3><p className="text-sm text-muted-foreground mt-1">Необратимые действия с данными системы</p></div></div>
          <div className="flex flex-wrap gap-3">
            <Button variant="destructive" size="sm" className="rounded-xl cursor-pointer" onClick={() => setClearDataOpen(true)}><Trash2 className="w-4 h-4 mr-2" />Очистить все данные</Button>
            <Button variant="outline" size="sm" className="rounded-xl border-destructive/30 text-destructive hover:bg-destructive/10 cursor-pointer" onClick={() => setResetSettingsOpen(true)}>Сбросить настройки</Button>
          </div>
        </div>
      </div>

      <AlertDialog open={clearDataOpen} onOpenChange={setClearDataOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader><AlertDialogTitle>Очистить все данные?</AlertDialogTitle><AlertDialogDescription>Все данные системы будут безвозвратно удалены. Это действие нельзя отменить.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel className="rounded-xl cursor-pointer">Отмена</AlertDialogCancel><AlertDialogAction className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90 cursor-pointer" onClick={() => { setClearDataOpen(false); toast.error('Действие заблокировано в демо-режиме') }}>Очистить</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={resetSettingsOpen} onOpenChange={setResetSettingsOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader><AlertDialogTitle>Сбросить настройки?</AlertDialogTitle><AlertDialogDescription>Все настройки будут возвращены к значениям по умолчанию. Это действие нельзя отменить.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel className="rounded-xl cursor-pointer">Отмена</AlertDialogCancel><AlertDialogAction className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90 cursor-pointer" onClick={() => { setResetSettingsOpen(false); toast.error('Действие заблокировано в демо-режиме') }}>Сбросить</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ---- Profile Page ----

function ProfilePage({ user, onUserUpdate }: { user: AuthUser; onUserUpdate: (updates: Partial<AuthUser>) => void }) {
  const userInitials = user.name ? user.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) : 'A'
  const [profileName, setProfileName] = useState(user.name || '')
  const [profileEmail, setProfileEmail] = useState(user.email || '')
  const [profileAvatar, setProfileAvatar] = useState(user.avatarUrl || '')

  const handleSave = () => {
    onUserUpdate({ name: profileName, email: profileEmail, avatarUrl: profileAvatar || null })
    toast.success('Профиль обновлён')
  }

  return (
    <div className="space-y-6">
      <div><h2 className="text-2xl font-bold tracking-tight">Профиль</h2><p className="text-muted-foreground mt-1">Управление вашим аккаунтом</p></div>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border bg-card shadow-sm flex flex-col overflow-hidden">
          <div className="h-24 bg-gradient-to-br from-slate-800 to-slate-900 dark:from-slate-200 dark:to-slate-300 relative"><div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.1),transparent)]" /></div>
          <div className="flex flex-col items-center text-center -mt-12 px-6 pb-6">
            <Avatar className="h-24 w-24 ring-4 ring-background shadow-lg mb-4">
              <AvatarImage src={user.avatarUrl || undefined} alt={user.name || 'Пользователь'} />
              <AvatarFallback className="text-2xl bg-gradient-to-br from-slate-700 to-slate-900 dark:from-slate-200 dark:to-slate-300 text-white dark:text-slate-900 font-bold">{userInitials}</AvatarFallback>
            </Avatar>
            <h3 className="text-lg font-bold">{user.name || 'Пользователь'}</h3>
            <p className="text-sm text-muted-foreground mt-0.5">{user.email || 'Нет email'}</p>
            <Badge className="mt-3" variant="secondary"><Shield className="w-3 h-3 mr-1" />Администратор</Badge>
            <Separator className="my-4 w-full" />
            <div className="w-full space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">ИД Яндекс</span><span className="font-mono text-xs">{user.yaId}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Роль</span><span className="font-medium">{user.role}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">ИД</span><span className="font-mono text-xs">{user.id.slice(0, 12)}...</span></div>
            </div>
          </div>
        </div>
        <div className="lg:col-span-2 rounded-2xl border bg-card p-6 shadow-sm space-y-6">
          <div><h3 className="font-semibold text-base mb-1">Редактирование профиля</h3><p className="text-sm text-muted-foreground">Обновите вашу личную информацию</p></div>
          <Separator />
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label htmlFor="profile-name">Имя</Label><Input id="profile-name" value={profileName} onChange={(e) => setProfileName(e.target.value)} className="rounded-xl" /></div>
            <div className="space-y-2"><Label htmlFor="profile-email">Email</Label><Input id="profile-email" type="email" value={profileEmail} onChange={(e) => setProfileEmail(e.target.value)} className="rounded-xl" /></div>
            <div className="sm:col-span-2 space-y-2"><Label htmlFor="profile-avatar">URL аватара</Label><Input id="profile-avatar" value={profileAvatar} onChange={(e) => setProfileAvatar(e.target.value)} placeholder="https://..." className="rounded-xl" /></div>
          </div>
          <div className="flex gap-3">
            <Button className="rounded-xl cursor-pointer" onClick={handleSave}>Сохранить</Button>
            <Button variant="outline" className="rounded-xl cursor-pointer" onClick={() => { setProfileName(user.name || ''); setProfileEmail(user.email || ''); setProfileAvatar(user.avatarUrl || '') }}>Отмена</Button>
          </div>
          <Separator />
          <div>
            <h3 className="font-semibold text-base mb-1">Сессии</h3>
            <p className="text-sm text-muted-foreground mb-4">Активные сеансы авторизации</p>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl border bg-accent/30">
                <div className="flex items-center gap-3"><div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" /><div><p className="text-sm font-medium">Текущая сессия</p><p className="text-[11px] text-muted-foreground">Chrome · Linux · Сейчас</p></div></div>
                <Badge variant="secondary" className="text-[10px]">Активна</Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ---- Search Dialog ----

function SearchDialog({ open, onOpenChange, onNavigate }: { open: boolean; onOpenChange: (open: boolean) => void; onNavigate: (id: string) => void }) {
  const [query, setQuery] = useState('')
  const searchResults = query.trim() ? sidebarItems.filter(item => item.label.toLowerCase().includes(query.toLowerCase())) : sidebarItems

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) setQuery('') }}>
      <DialogContent className="sm:max-w-[500px] p-0 gap-0 overflow-hidden rounded-2xl">
        <DialogHeader className="sr-only"><DialogTitle>Поиск</DialogTitle><DialogDescription>Поиск по системе</DialogDescription></DialogHeader>
        <div className="flex items-center border-b px-4">
          <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
          <Input placeholder="Поиск по системе..." value={query} onChange={(e) => setQuery(e.target.value)} className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 h-12 text-base" autoFocus />
          <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground ml-2">ESC</kbd>
        </div>
        <div className="p-4">
          <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wider">Быстрый переход</p>
          <div className="space-y-1">
            {searchResults.map((item) => {
              const Icon = item.icon
              return (
                <button key={item.id} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm hover:bg-accent transition-colors text-left cursor-pointer" onClick={() => { onNavigate(item.id); onOpenChange(false); setQuery('') }}>
                  <Icon className="w-4 h-4 text-muted-foreground" /><span>{item.label}</span><ChevronRight className="w-3 h-3 ml-auto text-muted-foreground" />
                </button>
              )
            })}
            {searchResults.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">Ничего не найдено</p>}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ---- Notifications Panel ----

function NotificationsPanel() {
  const [notifications, setNotifications] = useState(mockNotifications)
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null)
  const [notifDetailOpen, setNotifDetailOpen] = useState(false)
  const unreadCount = notifications.filter(n => !n.read).length

  const markAllRead = () => setNotifications(prev => prev.map(n => ({ ...n, read: true })))

  const handleNotifClick = (n: Notification) => {
    if (!n.read) setNotifications(prev => prev.map(x => x.id === n.id ? { ...x, read: true } : x))
    setSelectedNotification(n)
    setNotifDetailOpen(true)
  }

  const typeIcons: Record<string, React.ComponentType<{ className?: string }>> = { info: Info, success: CheckCircle2, warning: AlertCircle, error: AlertCircle }
  const typeColors: Record<string, string> = { info: 'text-sky-500', success: 'text-emerald-500', warning: 'text-amber-500', error: 'text-destructive' }

  return (
    <>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="icon" className="relative cursor-pointer">
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground animate-pulse">{unreadCount}</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-[380px] p-0 rounded-2xl shadow-xl">
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2"><h4 className="font-semibold text-sm">Уведомления</h4>{unreadCount > 0 && <Badge variant="secondary" className="text-[10px] h-5">{unreadCount} новых</Badge>}</div>
            <Button variant="ghost" size="sm" className="text-xs h-7 cursor-pointer" onClick={markAllRead}>Прочитать все</Button>
          </div>
          <ScrollArea className="h-[320px]">
            <div className="p-2">
              {notifications.map((n) => {
                const Icon = typeIcons[n.type]
                return (
                  <div key={n.id} className={`flex items-start gap-3 p-3 rounded-xl transition-colors hover:bg-accent/50 cursor-pointer ${!n.read ? 'bg-accent/30' : ''}`} onClick={() => handleNotifClick(n)}>
                    <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${typeColors[n.type]}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2"><p className="text-sm font-medium">{n.title}</p>{!n.read && <div className="w-1.5 h-1.5 bg-primary rounded-full shrink-0" />}</div>
                      <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
                      <p className="text-[10px] text-muted-foreground/60 mt-1">{n.time}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </ScrollArea>
          <div className="p-3 border-t"><Button variant="ghost" size="sm" className="w-full text-xs h-8 rounded-xl cursor-pointer">Все уведомления</Button></div>
        </PopoverContent>
      </Popover>

      <Dialog open={notifDetailOpen} onOpenChange={setNotifDetailOpen}>
        <DialogContent className="sm:max-w-[400px] rounded-2xl">
          {selectedNotification && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">{(() => { const NIcon = typeIcons[selectedNotification.type]; return <NIcon className={`w-5 h-5 ${typeColors[selectedNotification.type]}`} /> })()}{selectedNotification.title}</DialogTitle>
                <DialogDescription>{selectedNotification.time}</DialogDescription>
              </DialogHeader>
              <p className="text-sm py-2">{selectedNotification.message}</p>
              <DialogFooter><Button variant="outline" className="rounded-xl cursor-pointer" onClick={() => setNotifDetailOpen(false)}>Закрыть</Button></DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

// ---- Footer ----

function Footer() {
  return (
    <footer className="border-t bg-card mt-auto">
      <div className="px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs text-muted-foreground"><Shield className="w-3 h-3" /><span>{APP_VERSION}</span><span>·</span><span>&copy; {new Date().getFullYear()} СавинцевАвтоЦентр</span></div>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <button className="hover:text-foreground transition-colors cursor-pointer flex items-center gap-1" onClick={() => toast.info('Документация доступна в разделе помощи', { description: 'Свяжитесь с администратором для получения доступа' })}><FileText className="w-3 h-3" />Документация</button>
          <button className="hover:text-foreground transition-colors cursor-pointer flex items-center gap-1" onClick={() => toast.info('Техподдержка: support@savincevac.ru', { description: 'Рабочие часы: Пн-Пт 9:00-18:00' })}><ExternalLink className="w-3 h-3" />Поддержка</button>
          <button className="hover:text-foreground transition-colors cursor-pointer flex items-center gap-1" onClick={() => toast.info('СавинцевАвтоЦентр — система управления автосервисом', { description: `Версия ${APP_VERSION} · Powered by Next.js` })}><Heart className="w-3 h-3" />О системе</button>
        </div>
      </div>
    </footer>
  )
}

// ---- Main Admin Panel ----

interface AdminPanelProps {
  user: AuthUser
  onLogout: () => void
  onUserUpdate: (updates: Partial<AuthUser>) => void
}

export function AdminPanel({ user, onLogout, onUserUpdate }: AdminPanelProps) {
  const [activeItem, setActiveItem] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [createOrderOpen, setCreateOrderOpen] = useState(false)
  const [logoutConfirmOpen, setLogoutConfirmOpen] = useState(false)
  const { theme, setTheme } = useTheme()

  const userInitials = user.name ? user.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) : 'A'

  // Fetch orders from API
  const fetchOrders = useCallback(async () => {
    try {
      const res = await fetch('/api/orders')
      if (res.ok) {
        const data = await res.json()
        setOrders(data.orders)
      } else {
        toast.error('Ошибка загрузки заявок')
      }
    } catch {
      toast.error('Ошибка подключения к серверу')
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Seed orders if empty
  useEffect(() => {
    async function init() {
      try {
        const res = await fetch('/api/orders')
        if (res.ok) {
          const data = await res.json()
          if (data.orders.length === 0) {
            await fetch('/api/seed', { method: 'POST' })
          }
        }
      } catch {
        // ignore
      }
      fetchOrders()
    }
    init()
  }, [fetchOrders])

  const handleItemSelect = useCallback((id: string) => {
    setActiveItem(id)
    setSidebarOpen(false)
  }, [])

  const handleCreateOrder = useCallback(() => {
    setActiveItem('orders')
    setCreateOrderOpen(true)
  }, [])

  // Keyboard shortcut: Cmd+K / Ctrl+K
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setSearchOpen(true)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  const handleLogoutConfirm = () => {
    setLogoutConfirmOpen(true)
  }

  const handleLogoutAction = () => {
    setLogoutConfirmOpen(false)
    onLogout()
  }

  const renderPage = () => {
    switch (activeItem) {
      case 'dashboard':
        return <DashboardPage user={user} onNavigate={handleItemSelect} onCreateOrder={handleCreateOrder} orders={orders} isLoading={isLoading} />
      case 'orders':
        return <OrdersPage orders={orders} setOrders={setOrders} createOpen={createOrderOpen} setCreateOpen={setCreateOrderOpen} isLoading={isLoading} />
      case 'clients':
        return <ClientsPage orders={orders} />
      case 'analytics':
        return <AnalyticsPage orders={orders} isLoading={isLoading} />
      case 'settings':
        return <SettingsPage />
      case 'profile':
        return <ProfilePage user={user} onUserUpdate={onUserUpdate} />
      default:
        return <DashboardPage user={user} onNavigate={handleItemSelect} onCreateOrder={handleCreateOrder} orders={orders} isLoading={isLoading} />
    }
  }

  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex h-screen bg-background">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex w-64 border-r bg-card flex-col shrink-0">
          <SidebarContent user={user} activeItem={activeItem} onItemSelect={handleItemSelect} orders={orders} />
        </aside>

        {/* Main Area */}
        <div className="flex flex-col flex-1 min-w-0">
          {/* Top Bar */}
          <header className="sticky top-0 z-30 border-b bg-card/80 backdrop-blur-lg">
            <div className="flex items-center justify-between h-14 px-4 lg:px-6">
              <div className="flex items-center gap-3">
                {/* Mobile Sidebar Toggle */}
                <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="icon" className="lg:hidden cursor-pointer"><Menu className="h-5 w-5" /></Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="p-0 w-64">
                    <SheetHeader className="sr-only"><SheetTitle>Навигация</SheetTitle></SheetHeader>
                    <SidebarContent user={user} activeItem={activeItem} onItemSelect={handleItemSelect} orders={orders} />
                  </SheetContent>
                </Sheet>
                <h1 className="text-sm font-semibold text-muted-foreground hidden sm:block">
                  {sidebarItems.find(i => i.id === activeItem)?.label || 'Главная'}
                </h1>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="cursor-pointer" onClick={() => setSearchOpen(true)}><Search className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" className="cursor-pointer" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
                  {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                </Button>
                <NotificationsPanel />
                <Separator orientation="vertical" className="h-6 mx-1" />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center gap-2 cursor-pointer px-2">
                      <Avatar className="h-7 w-7"><AvatarImage src={user.avatarUrl || undefined} alt={user.name || 'Пользователь'} /><AvatarFallback className="text-[10px] bg-gradient-to-br from-slate-700 to-slate-900 dark:from-slate-200 dark:to-slate-300 text-white dark:text-slate-900 font-semibold">{userInitials}</AvatarFallback></Avatar>
                      <span className="hidden sm:block text-sm font-medium max-w-[120px] truncate">{user.name || 'Админ'}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 rounded-xl">
                    <DropdownMenuLabel>{user.email || 'Аккаунт'}</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="cursor-pointer" onClick={() => handleItemSelect('profile')}><UserCircle className="mr-2 h-4 w-4" />Профиль</DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => handleItemSelect('settings')}><Settings className="mr-2 h-4 w-4" />Настройки</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="cursor-pointer text-destructive focus:text-destructive" onClick={handleLogoutConfirm}><LogOut className="mr-2 h-4 w-4" />Выйти</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 overflow-y-auto">
            <div className="p-4 lg:p-6 max-w-[1400px] mx-auto">
              {renderPage()}
            </div>
            <Footer />
          </main>
        </div>

        {/* Search Dialog */}
        <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} onNavigate={handleItemSelect} />

        {/* Logout Confirmation */}
        <AlertDialog open={logoutConfirmOpen} onOpenChange={setLogoutConfirmOpen}>
          <AlertDialogContent className="rounded-2xl">
            <AlertDialogHeader>
              <AlertDialogTitle>Выйти из системы?</AlertDialogTitle>
              <AlertDialogDescription>Вы будете разлогинены и перенаправлены на страницу входа.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="rounded-xl cursor-pointer">Отмена</AlertDialogCancel>
              <AlertDialogAction className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90 cursor-pointer" onClick={handleLogoutAction}>Выйти</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </TooltipProvider>
  )
}
