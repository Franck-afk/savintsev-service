'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Shield, Loader2, Fingerprint, KeyRound } from 'lucide-react'
import type { AuthUser } from '@/app/page'

interface LoginPageProps {
  onLogin: (user: AuthUser) => void
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [isLoadingYandex, setIsLoadingYandex] = useState(false)
  const [isLoadingDemo, setIsLoadingDemo] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleYandexLogin = async () => {
    setIsLoadingYandex(true)
    setError(null)
    try {
      const res = await fetch('/api/auth/yandex', { method: 'POST' })
      const data = await res.json()

      if (data.url) {
        window.location.href = data.url
      } else {
        setError(data.message || 'Ошибка конфигурации Яндекс OAuth')
        setIsLoadingYandex(false)
      }
    } catch {
      setError('Ошибка соединения с сервером')
      setIsLoadingYandex(false)
    }
  }

  const handleDemoLogin = async () => {
    setIsLoadingDemo(true)
    setError(null)
    try {
      const res = await fetch('/api/auth/demo', { method: 'POST' })
      const data = await res.json()

      if (data.success && data.user) {
        onLogin(data.user)
      } else {
        setError(data.error || 'Ошибка демо-входа')
      }
    } catch {
      setError('Ошибка соединения с сервером')
    } finally {
      setIsLoadingDemo(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-primary/20 rounded-full" />
        <div className="absolute top-3/4 right-1/3 w-1.5 h-1.5 bg-primary/15 rounded-full" />
        <div className="absolute top-1/2 right-1/4 w-1 h-1 bg-primary/25 rounded-full" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo and Title */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-5">
            <div className="flex items-center justify-center w-18 h-18 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 dark:from-slate-100 dark:to-slate-200 text-white dark:text-slate-900 shadow-xl shadow-slate-300/30 dark:shadow-slate-900/50 p-4">
              <Shield className="w-9 h-9" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-white rounded-full" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight">СавинцевАвтоЦентр</h1>
          <p className="text-muted-foreground mt-2 text-center">Войдите для доступа к панели управления</p>
        </div>

        <Card className="shadow-2xl border-0 shadow-slate-200/60 dark:shadow-slate-900/60 backdrop-blur-sm bg-white/80 dark:bg-slate-900/80">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-muted-foreground" />
              Авторизация
            </CardTitle>
            <CardDescription>Выберите способ входа в систему</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Yandex Login Button */}
            <Button
              onClick={handleYandexLogin}
              disabled={isLoadingYandex || isLoadingDemo}
              className="w-full h-12 text-base font-medium bg-[#FC3F1D] hover:bg-[#e63510] text-white shadow-md hover:shadow-lg transition-all duration-200 rounded-xl"
              size="lg"
            >
              {isLoadingYandex ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <svg className="mr-2 h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z" />
                </svg>
              )}
              Войти через Яндекс
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <Separator className="w-full" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-3 text-muted-foreground font-medium">или</span>
              </div>
            </div>

            {/* Demo Login Button */}
            <Button
              onClick={handleDemoLogin}
              disabled={isLoadingYandex || isLoadingDemo}
              variant="outline"
              className="w-full h-12 text-base font-medium border-2 hover:bg-accent transition-all duration-200 rounded-xl group"
              size="lg"
            >
              {isLoadingDemo ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : (
                <Fingerprint className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
              )}
              Демо-вход
            </Button>

            {/* Error Message */}
            {error && (
              <div className="rounded-xl bg-destructive/10 border border-destructive/20 p-4 text-sm text-destructive flex items-start gap-2">
                <div className="w-1 h-1 bg-destructive rounded-full mt-1.5 shrink-0" />
                {error}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 flex flex-col items-center gap-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
            <span>Защищено с помощью Яндекс OAuth 2.0 и JWT</span>
          </div>
          <p className="text-[11px] text-muted-foreground/60">v1.2.0 · Все права защищены</p>
        </div>
      </div>
    </div>
  )
}
