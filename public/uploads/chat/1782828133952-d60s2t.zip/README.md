# СавинцевАвтоЦентр — Панель управления

Административная панель автосервиса «СавинцевАвтоЦентр» с авторизацией через Yandex OAuth 2.0, построенная на современном стеке Next.js 16, React 19, TypeScript и shadcn/ui.

---

## Технологический стек

| Категория | Технология |
|-----------|-----------|
| **Фреймворк** | Next.js 16 (App Router) |
| **Язык** | TypeScript 5 |
| **UI** | React 19 + shadcn/ui (New York) |
| **Стилизация** | Tailwind CSS 4 |
| **Иконки** | Lucide React |
| **Графики** | Recharts + shadcn/ui Chart |
| **Тема** | next-themes (светлая / тёмная / системная) |
| **База данных** | Prisma ORM + SQLite / PostgreSQL |
| **Аутентификация** | JWT (jose) + Yandex OAuth 2.0 |
| **Анимации** | Framer Motion + Tailwind CSS Transitions |
| **Пакетный менеджер** | npm |

---

## Быстрый старт

### Установка зависимостей

```bash
npm install
```

### Настройка базы данных

```bash
npm run db:push
```

### Запуск в режиме разработки

```bash
npm run dev
```

Приложение будет доступно на `http://localhost:3000`.

### Проверка кода

```bash
npm run lint
```

---

## Переменные окружения

Создайте файл `.env` в корне проекта:

```env
# База данных (SQLite — по умолчанию)
DATABASE_URL="file:./dev.db"

# JWT секрет (обязательно измените в продакшене)
JWT_SECRET="your-super-secret-jwt-key"

# Yandex OAuth 2.0 (необязательно — без них работает демо-вход)
YANDEX_CLIENT_ID="your-yandex-client-id"
YANDEX_CLIENT_SECRET="your-yandex-client-secret"
YANDEX_REDIRECT_URI="https://your-domain.com/api/auth/yandex/callback"
```

> Для получения Yandex OAuth-credentials: [oauth.yandex.ru](https://oauth.yandex.ru)

---

## Переключение на PostgreSQL

По умолчанию проект использует **SQLite** — он работает без установки и подходит для разработки. Для продакшена рекомендуется **PostgreSQL**.

### Шаг 1: Установите PostgreSQL

```bash
# Ubuntu/Debian
sudo apt install postgresql postgresql-contrib

# macOS
brew install postgresql@16

# Docker
docker run -d --name admin-panel-pg \
  -e POSTGRES_USER=admin \
  -e POSTGRES_PASSWORD=password \
  -e POSTGRES_DB=admin_panel \
  -p 5432:5432 \
  postgres:16
```

### Шаг 2: Создайте базу данных

```bash
sudo -u postgres psql
CREATE DATABASE admin_panel;
CREATE USER admin WITH PASSWORD 'password';
GRANT ALL PRIVILEGES ON DATABASE admin_panel TO admin;
```

### Шаг 3: Переключите схему Prisma

```bash
# Скопируйте PostgreSQL-схему вместо текущей
cp prisma/schema.postgresql.prisma prisma/schema.prisma
```

### Шаг 4: Обновите `.env`

```env
# Замените SQLite-строку на PostgreSQL
DATABASE_URL="postgresql://admin:password@localhost:5432/admin_panel?schema=public"
```

### Шаг 5: Примените схему и запустите

```bash
npm run db:push
npm run dev
```

### Обратное переключение на SQLite

```bash
cp prisma/schema.sqlite.prisma prisma/schema.prisma
# Обновите .env: DATABASE_URL="file:./dev.db"
npm run db:push
npm run dev
```

> **Примечание:** Файлы схем хранятся в `prisma/`:
> - `schema.prisma` — текущая активная схема
> - `schema.sqlite.prisma` — шаблон для SQLite
> - `schema.postgresql.prisma` — шаблон для PostgreSQL

---

## Архитектура

```
src/
├── app/
│   ├── layout.tsx                          # Корневой layout + ThemeProvider + Toaster
│   ├── page.tsx                            # Маршрутизация по состоянию авторизации
│   └── api/auth/
│       ├── yandex/route.ts                 # POST — генерация URL OAuth-авторизации
│       ├── yandex/callback/route.ts        # GET — обработка OAuth-коллбэка
│       ├── me/route.ts                     # GET — получение текущего пользователя
│       ├── logout/route.ts                 # POST — выход из системы
│       └── demo/route.ts                   # POST — демо-вход без Yandex
├── components/
│   ├── login-page.tsx                      # Страница входа
│   ├── admin-panel.tsx                     # Админ-панель (все страницы)
│   ├── loading-screen.tsx                  # Экран загрузки
│   └── ui/                                 # shadcn/ui компоненты
├── lib/
│   ├── auth.ts                             # JWT-утилиты (создание, проверка, cookie)
│   ├── db.ts                               # Prisma-клиент
│   └── utils.ts                            # Общие утилиты (cn)
prisma/
├── schema.prisma                           # Активная схема (SQLite или PostgreSQL)
├── schema.sqlite.prisma                    # Шаблон для SQLite
└── schema.postgresql.prisma                # Шаблон для PostgreSQL
```

---

## Аутентификация

### Yandex OAuth 2.0

Полный поток авторизации:

1. Пользователь нажимает **«Войти через Яндекс»**
2. `POST /api/auth/yandex` → возвращает URL авторизации Яндекса
3. Редирект на `oauth.yandex.ru/authorize`
4. После подтверждения — коллбэк на `GET /api/auth/yandex/callback?code=...`
5. Сервер обменивает `code` на `access_token`
6. Получает данные пользователя через `login.yandex.ru/info`
7. Создаёт/обновляет пользователя в БД (Prisma upsert)
8. Генерирует JWT и устанавливает HTTP-only cookie
9. Редирект на главную страницу

### Демо-вход

Для тестирования без реальных Yandex-учётных данных:

- `POST /api/auth/demo` — создаёт пользователя «Demo Admin» с ролью `admin`
- Устанавливает JWT cookie, как при обычной авторизации

### JWT-механизм

- Алгоритм: **HS256** (библиотека `jose`)
- Хранение: **HTTP-only cookie** (`admin_token`)
- Срок действия: **7 дней**
- Payload: `id`, `yaId`, `email`, `name`, `avatarUrl`, `role`

---

## API-эндпоинты

| Метод | Путь | Описание |
|-------|------|----------|
| `POST` | `/api/auth/yandex` | Возвращает URL для OAuth-авторизации Яндекса |
| `GET` | `/api/auth/yandex/callback` | Обрабатывает OAuth-коллбэк, создаёт пользователя, устанавливает JWT |
| `GET` | `/api/auth/me` | Возвращает данные текущего пользователя из JWT |
| `POST` | `/api/auth/logout` | Очищает JWT-куку, разлогинивает |
| `POST` | `/api/auth/demo` | Создаёт демо-пользователя и устанавливает JWT |

---

## База данных

Проект поддерживает **две базы данных** через Prisma ORM:

| БД | Статус | Рекомендация |
|----|--------|-------------|
| **SQLite** | По умолчанию | Для разработки и тестирования |
| **PostgreSQL** | Готово к использованию | Для продакшена |

> Модель данных одинакова для обеих БД. Код приложения менять не нужно — только схему Prisma и `DATABASE_URL`.

### Модель `User`

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | `String` (cuid) | Уникальный идентификатор |
| `yaId` | `String` (unique) | ID пользователя в Яндексе |
| `email` | `String?` | Email-адрес |
| `name` | `String?` | Имя пользователя |
| `avatarUrl` | `String?` | URL аватара |
| `role` | `String` | Роль (по умолчанию `"admin"`) |
| `createdAt` | `DateTime` | Дата создания |
| `updatedAt` | `DateTime` | Дата последнего обновления |

---

## Страницы админ-панели

### Dashboard (Главная)

- Приветствие по имени + текущая дата
- 4 карточки статистики (пользователи, посещения, сессии, аптайм) с трендами
- BarChart — посещения и сессии за 7 месяцев
- AreaChart — нагрузка сервера (CPU и память) за неделю
- Быстрые действия (добавить пользователя, создать отчёт, проверить систему)
- Последняя активность (5 записей с цветными бейджами)

### Настройки

- **Общие:** название системы, email администратора, часовой пояс
- **Безопасность:** двухфакторная аутентификация, email-уведомления, режим обслуживания, срок JWT
- **Опасная зона:** очистка данных, сброс настроек

### Профиль

- Карточка профиля (аватар, имя, email, роль, Yandex ID)
- Форма редактирования (имя, email, URL аватара)
- Секция активных сессий

---

## UI/UX

- **Тёмная / светлая тема** с переключателем в шапке
- **Адаптивный дизайн** — мобильная версия с выдвижным сайдбаром (Sheet)
- **Cursor pointer** на всех интерактивных элементах
- **Анимации:** hover-эффекты, плавные переходы, масштабирование иконок
- **Скруглённые углы** (`rounded-2xl`, `rounded-xl`)
- **Градиенты** на аватарах и логотипе
- **Цветовая кодировка** ролей, статусов и типов действий
- **Sticky footer** — корректное позиционирование

### Дополнительные компоненты

- **SearchDialog** — модальное окно поиска (Ctrl+K) с быстрым переходом по разделам
- **NotificationsPanel** — всплывающая панель уведомлений (5 типов: info, success, warning, error)
- **LoadingScreen** — спиннер при проверке авторизации

---

## Скрипты

| Команда | Описание |
|---------|----------|
| `npm run dev` | Запуск dev-сервера на порту 3000 |
| `npm run lint` | Проверка кода ESLint |
| `npm run db:push` | Применение схемы Prisma к БД |
| `npm run db:generate` | Генерация Prisma-клиента |
| `npm run db:migrate` | Создание и применение миграций |
| `npm run db:reset` | Сброс базы данных |
| `npm run build` | Сборка для продакшена |
| `npm run start` | Запуск продакшен-сервера |

---

## Лицензия

Частный проект. Все права защищены.
